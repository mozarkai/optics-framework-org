from typing import Optional, Any, Union, Tuple, Callable, List
import ast
import itertools
import operator
import re
from urllib.parse import urlparse, parse_qsl
import os.path
from datetime import datetime, timedelta, timezone
from functools import wraps
import json
import csv
import pandas as pd
from io import StringIO
from jsonpath_ng import parse as jsonpath_parse
import requests
from optics_framework.common.config_handler import ConfigHandler
from optics_framework.common.logging_config import internal_logger, execution_logger, register_secret
from optics_framework.common.session_manager import Session
from optics_framework.common.models import ApiData, ElementData
from optics_framework.common.caller_policy import refuse_server_read
from optics_framework.common.error import OpticsError, Code, plain
from optics_framework.common import expression, fallback, utils
from optics_framework.common.runner.data_reader import bind_params, step_arguments, step_candidates


NO_SESSION_PRESENT = "Session is None after ensure_session call."
NO_SESSION_ELEMENT_PRESENT = "Session elements is not an ElementData instance or is None."
ENV_SOURCE_PREFIX = "ENV:"
HAR_HEADER = b'{"log": {"version": "1.2", "creator": {"name": "Optics Framework", "version": "1.0"}, "entries": [\n'
HAR_TRAILER = b"\n]}}\n"


# A leading zero marks an id or a code ("007"), not a number.
_NUMBER = re.compile(r"[+-]?(0|[1-9]\d*)(\.\d+)?([eE][+-]?\d+)?")


def _as_number(text: str) -> int | float | None:
    """A whole number stays an int: a float rounds one past 2**53."""
    match = _NUMBER.fullmatch(text)
    if match is None:
        return None
    return float(text) if match.group(2) or match.group(3) else int(text)


def _names_in(source: str) -> set[str]:
    """The names a condition reads; a condition that is too long, too deep or does not parse is left for the evaluator to refuse."""
    if len(source) > expression.MAX_CHARS:
        return set(re.findall(r"\w+", source))
    try:
        return {node.id for node in ast.walk(ast.parse(source.strip(), mode="eval")) if isinstance(node, ast.Name)}
    except (SyntaxError, RecursionError, MemoryError):
        return set(re.findall(r"\w+", source))


def _by_number_with_numbers(compare: Callable[[Any, Any], bool]) -> Callable[[str, Any], bool]:
    def method(self: str, other: Any) -> bool:
        if isinstance(other, _Stored):
            other = _as_number(other) if _as_number(self) is not None and _as_number(other) is not None else str(other)
        number = _as_number(self) if isinstance(other, (int, float)) and not isinstance(other, bool) else None
        return compare(str(self) if number is None else number, other)
    return method


class _Stored(str):
    """A session value in a condition: text, which compares with a number, or with another value that reads as one, as the number it reads as."""

    __hash__ = str.__hash__
    __eq__ = _by_number_with_numbers(operator.eq)
    __ne__ = _by_number_with_numbers(operator.ne)
    __lt__ = _by_number_with_numbers(operator.lt)
    __le__ = _by_number_with_numbers(operator.le)
    __gt__ = _by_number_with_numbers(operator.gt)
    __ge__ = _by_number_with_numbers(operator.ge)


def reads_environment(file_path: Any) -> bool:
    return isinstance(file_path, str) and file_path.startswith(ENV_SOURCE_PREFIX)


def raw_params(*indices):
    """Decorator to mark parameter indices that should remain unresolved."""

    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            return func(*args, **kwargs)

        wrapper._raw_param_indices = indices  # pylint: disable=protected-access  # type: ignore[attr-defined]
        return wrapper

    return decorator


def substitutes_own_vars(func: Callable[..., Any]) -> Callable[..., Any]:
    """The keyword resolves ${name} itself, e.g. quoting it for a query, so the runner leaves it alone."""
    func._substitutes_own_vars = True  # pylint: disable=protected-access  # type: ignore[attr-defined]
    return func


def defines_variable(func: Callable[..., Any]) -> Callable[..., Any]:
    """The first param names a variable the keyword sets, so a dry run can count it as defined."""
    func._defines_variable = True  # pylint: disable=protected-access  # type: ignore[attr-defined]
    return func


def _append_har_entry(path: str, entry: bytes) -> None:
    """Add ``entry`` to the HAR at ``path`` by rewriting only its fixed trailer, so each call costs one entry."""
    if os.path.exists(path):
        with open(path, "r+b") as f:
            end = f.seek(0, os.SEEK_END) - len(HAR_TRAILER)
            if end >= len(HAR_HEADER):
                f.seek(end)
                if f.read(len(HAR_TRAILER)) == HAR_TRAILER:
                    f.seek(end)
                    f.write(b",\n" + entry + HAR_TRAILER)
                    return
    with open(path, "wb") as f:
        f.write(HAR_HEADER + entry + HAR_TRAILER)


class StepFailed(OpticsError):
    """A step inside a module failed; ``steps`` is the path from the outermost module down to that step."""

    show_cause = False

    def __init__(self, steps: tuple[str, ...], error: BaseException):
        self.steps = steps
        self.reason = error.reason if isinstance(error, StepFailed) else plain(error)
        super().__init__(Code.E0401, message=f"{' › '.join(steps)}: {self.reason}", cause=error)

    @classmethod
    def inside(cls, module: str, step: str, error: BaseException) -> "StepFailed":
        """``error`` from ``step`` of ``module``; a nested module's path replaces the step that ran it."""
        if isinstance(error, StepFailed):
            return cls((module, *error.steps), error)
        return cls((module, step), error)


class FlowControl:
    """Manages control flow operations (loops, conditions, data) for a session."""

    def __init__(
        self,
        session: Session,
        keyword_map: dict[str, Callable[..., Any]]
    ) -> None:
        self.session = session
        self.keyword_map = keyword_map
        self.config_handler: ConfigHandler = self.session.config_handler

    @property
    def modules(self) -> Any:
        """The session's modules as they are now, so a replacement reaches a FlowControl already built."""
        return self.session.modules

    def _ensure_session(self) -> None:
        """Ensures a Session instance is set."""
        if self.session is None:
            raise OpticsError(Code.E0501, message="FlowControl.session is not set. Please assign a valid session instance before using FlowControl.")

    def _resolve_param(self, param: str) -> str:
        """Resolve ${variable} references from session.elements, always returning a scalar (first value if list)."""
        if self.session is None:
            raise OpticsError(Code.E0702, message="Session is None in resolve_param.")
        return utils.resolve_scalar_param(self.session, param)

    def _get_validated_module_def(self, module_name: str) -> List[Tuple[str, List]]:
        """Validate session and modules, return the module definition or raise."""
        self._ensure_session()
        if self.session is None:
            raise OpticsError(Code.E0702, message=NO_SESSION_PRESENT)
        if self.modules is None or not hasattr(self.modules, "modules") or module_name not in self.modules.modules:
            raise OpticsError(Code.E0601, message=f"Module '{module_name}' not found in modules.")
        module_def = self.modules.get_module_definition(module_name)
        if not module_def:
            raise OpticsError(Code.E0601, message=f"No definition found for module '{module_name}'.")
        return module_def

    def _try_get_module_definition(self, keyword: str) -> Optional[Any]:
        """Return module definition for keyword if it names a module, else None."""
        if not self.modules:
            return None
        try:
            return self.modules.get_module_definition(keyword)
        except Exception:
            return None

    def _execute_nested_module(self, parent_module: str, keyword: str) -> Any:
        """Execute keyword as a nested module; raise on self-call or execution error."""
        if keyword == parent_module:
            raise OpticsError(Code.E0401, message=f"Module '{parent_module}' contains a self-call to '{keyword}'.")
        internal_logger.debug(f"Keyword '{keyword}' not found in keyword_map; invoking module '{keyword}'.")
        return self.execute_module(keyword)

    def _execute_keyword_method(
        self, method: Callable[..., Any], keyword: str, params: List[Any]
    ) -> Any:
        """Call the keyword on each value of its ``${name}`` params in turn, through the runner's fallback ladder."""
        elements = self._get_or_create_session_elements()
        params, store_as = utils.split_store_as(params)

        def attempt(combo: tuple[Any, ...]) -> Any:
            positional, named = step_arguments(method, combo, elements)
            bind_params(keyword, method, positional, named)
            execution_logger.info(f"Executing {keyword} with params: {positional} {named or ''}".rstrip())
            return utils.call_and_store(elements, method, positional, named, store_as)[0]

        return fallback.run(step_candidates(method, params, elements), attempt, f"keyword '{keyword}'")

    def _execute_single_keyword(
        self, module_name: str, keyword: str, params: List[Any]
    ) -> Any:
        """Execute one keyword: either as a mapped method or as a nested module."""
        func_name = "_".join(keyword.split()).lower()
        method = self.keyword_map.get(func_name)
        if method is not None:
            return self._execute_keyword_method(method, keyword, params)
        nested_def = self._try_get_module_definition(keyword)
        if nested_def is not None:
            return self._execute_nested_module(module_name, keyword)
        raise OpticsError(Code.E0402, message=f"'{keyword}' is not a keyword or a module")

    def execute_module(self, module_name: str) -> List[Any]:
        """Executes a module's keywords using the session's keyword_map.

        Not exposed on the Optics SDK — session.modules is only populated by
        CSV/YAML-driven execution; SDK/Robot Framework users should call keywords
        directly or write a real function/keyword instead.

        :param module_name: The module to execute.
        :return: Results of each keyword call in the module, in order.
        """
        module_def = self._get_validated_module_def(module_name)
        results = []
        execution_logger.info(f"Executing module: {module_name}")
        for keyword, params in module_def:
            try:
                results.append(self._execute_single_keyword(module_name, keyword, params))
            except Exception as e:
                internal_logger.error(f"Step '{keyword}' of module '{module_name}' failed: {e}")
                raise StepFailed.inside(module_name, keyword, e) from e
        return results

    @raw_params(1, 3, 5, 7, 9, 11, 13, 15)
    def run_loop(self, target: str, *args: str) -> List[Any]:
        """Runs a loop over a target module, either by count or with variables.

        :param target: The module name to execute in the loop.
        :param args: A single count (e.g. ``"5"``), or variable-iterable pairs
            (e.g. ``"${user}", "a|b|c"``) to iterate one value per run.
        :return: One result list per iteration.
        """
        internal_logger.debug(f"[RUN_LOOP] Called with target={target}, args={args}")
        self._ensure_session()
        if self.session is None:
            raise OpticsError(Code.E0702, message=NO_SESSION_PRESENT)
        if len(args) == 1:
            internal_logger.debug(f"[RUN_LOOP] Looping by count: {args[0]}")
            return self._loop_by_count(target, self._resolve_param(args[0]))
        internal_logger.debug(f"[RUN_LOOP] Looping with variables: {args}")
        return self._loop_with_variables(target, args)

    def _loop_by_count(self, target: str, count_str: str) -> List[Any]:
        """Runs a loop a specified number of times."""
        internal_logger.debug(f"[_LOOP_BY_COUNT] target={target}, count_str={count_str}")
        try:
            iterations = int(count_str)
            if iterations < 1:
                raise OpticsError(Code.E0403, message="Iteration count must be at least 1.")
        except ValueError as e:
            if str(e) == "Iteration count must be at least 1.":
                raise
            internal_logger.error(f"[_LOOP_BY_COUNT] Invalid count_str: {count_str}")
            raise OpticsError(Code.E0403, message=f"Expected an integer for loop count, got '{count_str}'.")

        results = []
        for i in range(iterations):
            internal_logger.debug(f"[_LOOP_BY_COUNT] Iteration {i + 1} of {iterations} for target '{target}'")
            result = self.execute_module(target)
            results.append(result)
        internal_logger.debug(f"[_LOOP_BY_COUNT] Completed {iterations} iterations for target '{target}'")
        return results

    def _loop_with_variables(self, target: str, args: Tuple[str, ...]) -> List[Any]:
        """Runs a loop with variable-iterable pairs."""
        internal_logger.debug(f"[_LOOP_WITH_VARIABLES] target={target}, args={args}")
        if len(args) % 2 != 0:
            internal_logger.error(f"[_LOOP_WITH_VARIABLES] Uneven number of arguments for variable-iterable pairs: {args}")
            raise OpticsError(Code.E0403, message="Expected an even number of arguments for variable-iterable pairs.")

        variables = args[0::2]
        iterables = args[1::2]
        internal_logger.debug(f"[_LOOP_WITH_VARIABLES] variables={variables}, iterables={iterables}")
        var_names, parsed_iterables = self._parse_variable_iterable_pairs(variables, iterables)
        min_length = min(len(lst) for lst in parsed_iterables)
        internal_logger.debug(f"[_LOOP_WITH_VARIABLES] min_length={min_length}, var_names={var_names}")
        if self.session is None:
            raise OpticsError(Code.E0501, message=NO_SESSION_PRESENT)
        runner_elements = self._get_or_create_session_elements()

        results = []
        for i in range(min_length):
            internal_logger.debug(f"[_LOOP_WITH_VARIABLES] Iteration {i + 1} of {min_length}")
            for var_name, iterable_values in zip(var_names, parsed_iterables):
                value = iterable_values[i]
                internal_logger.debug(f"[_LOOP_WITH_VARIABLES] Setting {var_name} = {value}")
                runner_elements.remove_element(var_name)
                runner_elements.add_element(var_name, value)
            internal_logger.debug(f"[_LOOP_WITH_VARIABLES] Executing target '{target}'")
            result = self.execute_module(target)
            results.append(result)
        internal_logger.debug(f"[_LOOP_WITH_VARIABLES] Completed {min_length} iterations for target '{target}'")
        return results

    def _parse_variable_iterable_pairs(
        self, variables: Tuple[str, ...], iterables: Tuple[str, ...]
    ) -> Tuple[List[str], List[List[Any]]]:
        """Parses variable names and their corresponding iterables."""
        var_names = self._parse_variable_names(variables)
        parsed_iterables = self._parse_iterables(variables, iterables)
        return var_names, parsed_iterables

    def _parse_variable_names(self, variables: Tuple[str, ...]) -> List[str]:
        """Extracts and cleans variable names from the input tuple."""
        var_names = []
        for variable in variables:
            if not isinstance(variable, str) or not variable.strip():
                raise OpticsError(Code.E0403, message=f"Invalid variable name: {variable}")
            var_name = variable.strip()
            if var_name.startswith("${") and var_name.endswith("}"):
                var_name = var_name[2:-1].strip()
            else:
                internal_logger.warning(
                    f"[RUN LOOP] Expected variable in format '${{name}}', got '{variable}'. Using as is."
                )
            var_names.append(var_name)
        return var_names

    def _parse_iterables(
        self, variables: Tuple[str, ...], iterables: Tuple[str, ...]
    ) -> List[List[Any]]:
        """Parses iterables into lists, handling JSON strings and validating input."""
        parsed_iterables = []
        for i, iterable in enumerate(iterables):
            parsed = self._parse_single_iterable(iterable, variables[i])
            if not parsed:
                raise OpticsError(Code.E0403, message=f"Iterable for variable '{variables[i]}' is empty.")
            parsed_iterables.append(parsed)
        return parsed_iterables

    def _parse_single_iterable(self, iterable: Any, variable: str) -> List[Any]:
        """Parses a single iterable, converting JSON strings, pipe-separated values, or validating lists."""
        if isinstance(iterable, str):
            # First try pipe-separated values
            if '|' in iterable:
                values = [value.strip() for value in iterable.split('|')]
                return values
            # Then try JSON parsing
            try:
                values = json.loads(iterable)
                if not isinstance(values, list):
                    raise OpticsError(Code.E0403, message=f"Iterable '{iterable}' for variable '{variable}' must resolve to a list.")
                return values
            except json.JSONDecodeError:
                raise OpticsError(Code.E0403, message=f"Invalid iterable format for variable '{variable}': '{iterable}'. Expected JSON list or pipe-separated values (value1|value2|value3).")
        elif isinstance(iterable, list):
            # Handle case where we get a list with a single string that contains pipe-separated values
            if len(iterable) == 1 and isinstance(iterable[0], str) and '|' in iterable[0]:
                values = [value.strip() for value in iterable[0].split('|')]
                return values
            return iterable
        else:
            raise OpticsError(Code.E0403, message=f"Expected a list, JSON string, or pipe-separated string for iterable of variable '{variable}', got {type(iterable).__name__}.")

    @substitutes_own_vars
    def condition(self, *args: str) -> Optional[List[Any]]:
        """Evaluates conditions and executes corresponding targets.

        :param args: Condition-target pairs, optionally ending with an else target:
            ``"cond1", "target1", "cond2", "target2", [else_target]``. A condition is a
            module name (prefix ``!`` to invert) or an expression.
        :return: Result of the matched target module, or None if nothing matched.
        """
        internal_logger.debug(f"[CONDITION] Called with args={args}")
        self._ensure_session()
        if self.session is None:
            raise OpticsError(Code.E0501, message=NO_SESSION_PRESENT)
        if not args:
            internal_logger.error("[CONDITION] No condition-target pairs provided.")
            raise OpticsError(Code.E0403, message="No condition-target pairs provided.")
        pairs, else_target = self._split_condition_args(args)
        internal_logger.debug(f"[CONDITION] Parsed pairs={pairs}, else_target={else_target}")
        execution_logger.debug(f"[CONDITION] Evaluating conditions: {pairs}, else_target={else_target}")
        return self._evaluate_conditions(pairs, else_target)

    def _split_condition_args(
        self, args: Tuple[str, ...]
    ) -> Tuple[List[Tuple[str, str]], Optional[str]]:
        """Splits args into condition-target pairs and an optional else target."""
        pairs = []
        else_target = None
        if len(args) % 2 == 1:
            for i in range(0, len(args) - 1, 2):
                pairs.append((args[i], args[i + 1]))
            else_target = args[-1]
        else:
            for i in range(0, len(args), 2):
                pairs.append((args[i], args[i + 1]))
        return pairs, else_target

    def _evaluate_conditions(
        self, pairs: List[Tuple[str, str]], else_target: Optional[str]
    ) -> Optional[List[Any]]:
        """
        Evaluates conditions and executes corresponding targets.
        For module-based conditions, returns the result of executing the module if non-empty.
        For expression-based conditions, executes the target if condition is true.
        If none are true, executes else_target if provided.
        """
        internal_logger.debug(f"[_EVALUATE_CONDITIONS] pairs={pairs}, else_target={else_target}")
        for idx, (cond, target) in enumerate(pairs):
            cond_str = cond.strip()
            execution_logger.info(f"Evaluating condition: '{cond_str}'")
            if not cond_str:
                continue
            if self._is_module_condition(cond_str):
                result = self._handle_module_condition(cond_str, target)
                if result is not None:
                    return result
            else:
                result = self._handle_expression_condition(cond_str, target)
                if result is not None:
                    return result
        if else_target is not None:
            internal_logger.debug(f"[_EVALUATE_CONDITIONS] No condition met. Executing ELSE block module '{else_target}'.")
            return self.execute_module(else_target)
        internal_logger.debug("[_EVALUATE_CONDITIONS] No condition met and no ELSE target provided.")
        return None

    def _is_module_condition(self, cond_str: str) -> Optional[bool]:
        """Checks if the condition string is a module name."""
        if not self.modules:
            return False
        # Strip "!" prefix if present before checking
        actual_cond = cond_str[1:].strip() if cond_str.startswith("!") else cond_str
        return self.modules.get_module_definition(actual_cond) is not None

    def _handle_module_condition(self, cond_str: str, target: str) -> Optional[List[Any]]:
        """Runs ``target`` when the condition module passes, or fails with a ``!`` prefix."""
        invert = cond_str.startswith("!")
        actual_cond = cond_str[1:].strip() if invert else cond_str
        if self._module_passes(actual_cond) == invert:
            internal_logger.debug(f"[_EVALUATE_CONDITIONS] Condition '{cond_str}' is not met. Skipping target '{target}'.")
            return None
        try:
            return self.execute_module(target)
        except StepFailed:
            raise
        except Exception as e:
            execution_logger.warning(f"[_EVALUATE_CONDITIONS] Target module '{target}' raised error: {e}.")
            raise StepFailed((target,), e) from e

    def _module_passes(self, module: str) -> bool:
        try:
            self.execute_module(module)
        except Exception as e:
            internal_logger.warning(f"[_EVALUATE_CONDITIONS] Module '{module}' raised error: {e}.")
            return False
        return True

    def _handle_expression_condition(self, cond_str: str, target: str) -> Optional[List[Any]]:
        """Handles evaluation and execution for expression-based conditions."""
        if self._is_condition_true(cond_str):
            internal_logger.debug(f"[_EVALUATE_CONDITIONS] Expression condition '{cond_str}' is True. Executing target '{target}'.")
            return self.execute_module(target)
        internal_logger.debug(f"[_EVALUATE_CONDITIONS] Expression condition '{cond_str}' is False.")
        return None

    def _is_condition_true(self, cond: str) -> bool:
        """A module name is true when the module runs and returns something; anything else is an expression. ``!`` inverts."""
        invert = cond.startswith("!")
        actual_cond = cond[1:].strip() if invert else cond
        if self.modules and hasattr(self.modules, "modules") and actual_cond in self.modules.modules:
            return self._module_succeeds(actual_cond) != invert
        try:
            resolved_cond, values = self._resolve_condition(actual_cond)
            internal_logger.debug(f"[_is_condition_true] Evaluating {resolved_cond} with {values}")
            return bool(self._safe_eval(resolved_cond, values)) != invert
        except Exception as e:
            if isinstance(e, OpticsError) and e.code is Code.E0406:
                raise
            if invert:
                internal_logger.debug(f"[_is_condition_true] Condition '{actual_cond}' failed, but inverting result to True.")
                return True
            raise OpticsError(Code.E0403, message=f"Cannot evaluate the condition '{cond}': {plain(e)}") from e

    def _module_succeeds(self, module: str) -> bool:
        try:
            return bool(self.execute_module(module))
        except Exception as e:
            internal_logger.warning(f"[_is_condition_true] Module '{module}' raised error: {e}. Treating as false condition.")
            return False

    def _resolve_condition(self, cond: str) -> tuple[str, dict[str, Any]]:
        """The condition with each ``${var}`` as a name, and those names' values, which compare with numbers as numbers."""
        if self.session is None:
            raise OpticsError(Code.E0501, message=NO_SESSION_PRESENT)
        runner_elements = getattr(self.session, "elements", None)
        if not isinstance(runner_elements, ElementData):
            raise OpticsError(Code.E0501, message=NO_SESSION_ELEMENT_PRESENT)
        taken = set(re.findall(r"\w+", cond))
        aliases = (alias for alias in (f"_var_{n}" for n in itertools.count()) if alias not in taken)
        values: dict[str, Any] = {}

        def replacer(ref: utils.VarRef) -> str:
            var_name = ref.name.strip()
            value = runner_elements.get_first(var_name)
            if value is None:
                raise OpticsError(Code.E0702, message=f"Variable '{var_name}' not found for condition resolution.")
            alias = next(aliases)
            values[alias] = _Stored(value)
            return alias

        resolved = utils.substitute_vars(cond, replacer)
        if values.keys() - _names_in(resolved):
            raise OpticsError(Code.E0403, message=f"Condition '{cond}' has a ${{variable}} inside quotes. Write it without the quotes.")
        return resolved, values

    @defines_variable
    @substitutes_own_vars
    @raw_params(0)
    def read_data(
        self, input_element: str, file_path: Union[str, List[Any]], query: str = ""
    ) -> List[Any]:
        """
        Reads tabular data from a CSV file, JSON file, environment variable, or a 2D list,
        applies optional filtering and column selection, and stores the result in the session's elements.

        :param input_element: Variable name where the result is stored (e.g. ``${data}``). Prefer ``${name}`` form.
        :param file_path: Data source. One of: (1) path to a ``.csv`` or ``.json`` file; (2) string
            ``ENV:VAR_NAME`` to use an environment variable (value parsed as JSON, CSV, or plain string);
            (3) a 2D list with first row as headers (Python API only).
        :param query: Optional semicolon-separated parts: ``select=col1,col2`` and/or filter expressions
            (pandas-style). Any ``${varname}`` in the query is resolved from `session.elements` before
            evaluation. Default ``""``.
        :returns: The stored value as a list (or list of lists for multi-row results). Also writes into
            `session.elements` under the name derived from `input_element`.
        """
        internal_logger.debug(f"[READ_DATA] Called with input_element={input_element}, file_path={file_path}, query={query}")
        self._ensure_session()
        if self.session is None:
            raise ValueError(NO_SESSION_PRESENT)
        elem_name = self._extract_element_name(input_element)
        internal_logger.debug(f"[READ_DATA] Extracted element name: {elem_name}")

        df, direct_env_value = self._load_data_frame(file_path)
        if direct_env_value is not None:
            # Always store the value in session.elements, even if not in ${name} format
            runner_elements = getattr(self.session, "elements", None)
            if isinstance(runner_elements, ElementData):
                register_secret(runner_elements.secrets, elem_name, direct_env_value)
                runner_elements.remove_element(elem_name)
                runner_elements.add_element(elem_name, direct_env_value)
            else:
                internal_logger.warning("[READ_DATA] Cannot store value: session.elements is not an ElementData instance.")
            return [direct_env_value]

        df = self._ensure_df_string(df)
        select_cols, filter_expr = self._parse_query_string(query)
        df = self._apply_filter(df, filter_expr, query)
        df = self._apply_column_selection(df, select_cols)
        result = self._format_result(df)
        store_value = self._store_result(elem_name, result)
        return store_value

    def _load_data_frame(self, file_path):
        """Loads data into a DataFrame from list, file, or environment variable."""
        if isinstance(file_path, list):
            data = file_path
            internal_logger.debug(f"[READ_DATA] Loading data from list, first row as headers: {data[0] if data and isinstance(data[0], list) else data}")
            if not data or not isinstance(data, list) or not data[0]:
                return pd.DataFrame(), None
            return pd.DataFrame(data[1:], columns=data[0]), None
        refuse_server_read(self.config_handler.config, "Read Data from a file or ENV: source")
        if reads_environment(file_path):
            return self._load_env_data(file_path.removeprefix(ENV_SOURCE_PREFIX))
        elif isinstance(file_path, str):
            return self._load_file_data(file_path), None
        else:
            internal_logger.error("[READ_DATA] file_path must be a list or a file path string.")
            raise OpticsError(Code.E0501, message="file_path must be a list or a file path string.")

    def _load_env_data(self, env_var):
        env_data = os.environ.get(env_var)
        internal_logger.debug(f"[READ_DATA] Loading data from environment variable: {env_var}")
        if env_data is None:
            raise OpticsError(Code.E0501, message=f"Environment variable '{env_var}' not found.")

        # Only try JSON parsing if the value looks like JSON (starts with [, {, or ")
        # This prevents numeric strings like "76e75538" from being parsed as scientific notation
        env_data_stripped = env_data.strip()
        looks_like_json = env_data_stripped.startswith(('{', '[', '"'))

        if looks_like_json:
            try:
                json_data = json.loads(env_data)
                internal_logger.debug(f"[READ_DATA] Parsed environment variable as JSON: {json_data}")
                # If the parsed JSON is a scalar (not list/dict), return as string
                if not isinstance(json_data, (list, dict)):
                    return pd.DataFrame(), str(json_data)
                normalized_data = self._normalize_json_data(json_data)
                return pd.json_normalize(normalized_data), None
            except json.JSONDecodeError:
                # Fall through to CSV parsing
                pass
            except Exception as e:
                internal_logger.error(f"[READ_DATA] Unexpected error occurred: {e}")
                raise OpticsError(Code.E0501, message=f"Unexpected error while loading environment variable '{env_var}': {e}", cause=e)

        # Try CSV parsing
        internal_logger.debug("[READ_DATA] Failed to parse environment variable as JSON, trying CSV.")
        try:
            df = pd.read_csv(StringIO(env_data))
            internal_logger.debug("[READ_DATA] Parsed environment variable as CSV.")
            if df.empty:
                return pd.DataFrame(), str(env_data)
            return df, None
        except ValueError:
            internal_logger.debug("[READ_DATA] Failed to parse environment variable as CSV, treating as direct value.")
            return pd.DataFrame(), str(env_data)

    def _normalize_json_data(self, json_data):
        """Normalizes JSON data to ensure it's in list format for DataFrame creation."""
        if not isinstance(json_data, dict):
            return json_data

        # Look for the first list value in the dictionary
        for v in json_data.values():
            if isinstance(v, list):
                return v

        # If no list found, convert dict to single-item list
        return [json_data]

    def _try_csv_parsing(self, env_data):
        """Attempts to parse environment data as CSV, falling back to direct value."""
        internal_logger.debug("[READ_DATA] Failed to parse environment variable as JSON, trying CSV.")
        try:
            df = pd.read_csv(StringIO(env_data))
            internal_logger.debug("[READ_DATA] Parsed environment variable as CSV.")
            if df.empty:
                return pd.DataFrame(), env_data
            return df, None
        except ValueError as e:
            internal_logger.debug("[READ_DATA] Failed to parse environment variable as CSV, treating as direct value.")
            raise OpticsError(Code.E0501, message=f"CSV parsing failed: {e}", cause=e)

    def _load_file_data(self, file_path):
        file_path = self._resolve_file_path(file_path)
        ext = self._get_file_extension(file_path)
        self._check_file_exists(file_path, ext)
        if ext == '.csv':
            return self._load_csv_file(file_path)
        elif ext == '.json':
            return self._load_json_file(file_path)
        else:
            internal_logger.error(f"[READ_DATA] Unsupported file extension: {ext}")
            raise OpticsError(Code.E0501, message=f"Unsupported file extension: {ext}")

    def _resolve_file_path(self, file_path):
        if not os.path.isabs(file_path):
            config_handler = self.config_handler
            project_path = getattr(config_handler.config, 'project_path', None)
            internal_logger.debug(f"[READ_DATA] Resolving relative file path. Project path: {project_path}")
            if project_path:
                file_path = os.path.join(project_path, file_path)
                internal_logger.debug(f"[READ_DATA] Resolved file path: {file_path}")
        return file_path

    def _get_file_extension(self, file_path):
        ext = os.path.splitext(file_path)[-1].lower()
        internal_logger.debug(f"[READ_DATA] File extension: {ext}")
        return ext

    def _check_file_exists(self, file_path, ext):
        if ext in ['.csv', '.json'] and not os.path.exists(file_path):
            internal_logger.error(f"[READ_DATA] File not found: {file_path}")
            raise OpticsError(Code.E0501, message=f"File '{file_path}' with extension '{ext}' does not exist.")

    def _load_csv_file(self, file_path):
        return pd.read_csv(file_path)

    def _load_json_file(self, file_path):
        with open(file_path, 'r', encoding='utf-8') as f:
            json_data = json.load(f)
        internal_logger.debug(f"[READ_DATA] Loaded JSON file: {file_path}")
        if isinstance(json_data, dict):
            for v in json_data.values():
                if isinstance(v, list):
                    json_data = v
                    break
            if isinstance(json_data, dict):
                json_data = [json_data]
        return pd.json_normalize(json_data)

    def _ensure_df_string(self, df):
        if df is not None and not df.empty:
            return df.astype(str)
        return df

    def _parse_query_string(self, query):
        select_cols = None
        filter_expr = None
        if query:
            internal_logger.debug(f"[READ_DATA] Parsing query: {query}")
            parts = [p.strip() for p in query.split(';') if p.strip()]
            for part in parts:
                resolved_part = self._resolve_query_vars(part)
                internal_logger.debug(f"[READ_DATA] Resolved query part: {resolved_part}")
                if resolved_part.startswith('select='):
                    select_cols = [c.strip() for c in resolved_part[7:].split(',') if c.strip()]
                    internal_logger.debug(f"[READ_DATA] Selected columns: {select_cols}")
                else:
                    filter_expr = resolved_part if filter_expr is None else f"{filter_expr} and {resolved_part}"
                    internal_logger.debug(f"[READ_DATA] Filter expression: {filter_expr}")
        return select_cols, filter_expr

    def _resolve_query_vars(self, q):
        runner_elements = self._get_or_create_session_elements()
        def replacer(ref: utils.VarRef) -> str:
            var_name = ref.name.strip()
            value = runner_elements.get_first(var_name)
            internal_logger.debug(f"[READ_DATA] Resolving variable in query: {var_name} -> {value}")
            if value is None:
                raise OpticsError(Code.E0702, message=f"Variable '{var_name}' not found in elements for query resolution.")
            if not isinstance(value, str):
                return str(value)
            text = value.replace("\\", "\\\\").replace("'", "\\'")
            quoted = q[ref.start - 1:ref.start] == "'" and q[ref.end:ref.end + 1] == "'"
            return text if quoted else f"'{text}'"
        return utils.substitute_vars(q, replacer)

    def _apply_filter(self, df, filter_expr, query):
        if filter_expr:
            df = expression.filter_rows(df, filter_expr)
            internal_logger.debug(f"[READ_DATA] Applied filter expression: {filter_expr}")
        if df is not None and df.empty and query:
            internal_logger.error(f"[READ_DATA] No data found matching the query/filter: '{query}'")
            raise OpticsError(Code.E0403, message=f"No data found matching the query/filter: '{query}'")
        return df

    def _apply_column_selection(self, df, select_cols):
        if select_cols:
            missing = [c for c in select_cols if c not in df.columns]
            if missing:
                internal_logger.error(f"[READ_DATA] Columns not found in data: {missing}")
                raise OpticsError(Code.E0403, message=f"Columns not found in data: {missing}")
            df = df.loc[:, select_cols]
            internal_logger.debug(f"[READ_DATA] Selected columns from DataFrame: {select_cols}")
        return df

    def _format_result(self, df):
        result = df.values.tolist()
        internal_logger.debug(f"[READ_DATA] Resulting data: {result}")
        if len(result) == 1:
            data = result[0]
        else:
            data = result
        def to_str(val):
            if isinstance(val, list):
                return [str(v) for v in val]
            return str(val)
        return to_str(data)

    def _store_result(self, elem_name, data_str):
        runner_elements = self.session.elements
        if isinstance(runner_elements, ElementData):
            if isinstance(data_str, list):
                store_value = ','.join(data_str)
            else:
                store_value = data_str
            register_secret(runner_elements.secrets, elem_name, store_value)
            internal_logger.debug(f"[READ_DATA] Storing value under element '{elem_name}': {store_value}")
            runner_elements.remove_element(elem_name)
            runner_elements.add_element(elem_name, store_value)
        else:
            internal_logger.warning("[READ_DATA] Cannot store value: session.elements is not an ElementData instance.")
            if isinstance(data_str, list):
                store_value = ','.join(data_str)
            else:
                store_value = data_str
        return [store_value] if not isinstance(data_str, list) else data_str

    def _load_data_with_query(self, file_path: Union[str, List[Any]], query: str) -> List[Any]:
        # Load as 2D list
        if isinstance(file_path, list):
            data = file_path
        else:
            data = self._load_csv_as_list(file_path)
        if not data or not isinstance(data, list) or not data[0]:
            return []
        headers = data[0]
        rows = data[1:]
        filters, select_cols = self._parse_query(query)
        # Apply filters
        filtered = []
        for row in rows:
            row_dict = {h: row[i] if i < len(row) else "" for i, h in enumerate(headers)}
            if all(str(row_dict.get(k, "")) == v for k, v in filters.items()):
                filtered.append(row_dict)
        # If no filters, use all rows
        if not filters:
            filtered = [{h: row[i] if i < len(row) else "" for i, h in enumerate(headers)} for row in rows]
        # Select columns
        if select_cols:
            result = [[row[c] for c in select_cols if c in row] for row in filtered]
        else:
            result = [list(row.values()) for row in filtered]
        return result

    def _parse_query(self, query: str) -> tuple[dict, list]:
        filters = {}
        select_cols = []
        if not query:
            return filters, select_cols
        parts = [p.strip() for p in query.split(';') if p.strip()]
        for part in parts:
            if part.startswith('select='):
                select_cols = [c.strip() for c in part[7:].split(',') if c.strip()]
            elif '=' in part:
                k, v = part.split('=', 1)
                filters[k.strip()] = v.strip()
        return filters, select_cols

    def _load_csv_as_list(self, file_path: str) -> list:
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File '{file_path}' not found.")
        if os.path.splitext(file_path)[-1].lower() != ".csv":
            raise ValueError("Unsupported file format. Use CSV or provide a list.")
        with open(file_path, newline="") as csvfile:
            reader = csv.reader(csvfile)
            data = list(reader)
        return data

    def _extract_element_name(self, input_element: str) -> str:
        """Extracts and cleans the element name from input."""
        elem_name = input_element.strip()
        if elem_name.startswith("${") and elem_name.endswith("}"):
            return elem_name[2:-1].strip()
        internal_logger.warning(
            f"[READ DATA] Expected element in format '${{name}}', got '{input_element}'. Using as is."
        )
        return elem_name

    def _load_data(
        self, file_path: Union[str, List[Any]], query: str
    ) -> List[Any]:
        """Loads data from a list or CSV file. 'query' is a column name or index for CSV."""
        if isinstance(file_path, list):
            return file_path
        return FlowControl._load_from_csv(file_path, query)


    @staticmethod
    def _load_from_csv(file_path: str, query: str) -> List[Any]:
        """Loads and extracts data from a CSV file using a column name or index as query."""
        if not os.path.exists(file_path):
            raise OpticsError(Code.E0501, message=f"File '{file_path}' not found.")
        if os.path.splitext(file_path)[-1].lower() != ".csv":
            raise OpticsError(Code.E0501, message="Unsupported file format. Use CSV or provide a list.")

        with open(file_path, newline="") as csvfile:
            reader = csv.reader(csvfile)
            data = list(reader)
            if not data:
                raise OpticsError(Code.E0501, message=f"CSV file '{file_path}' is empty.")
            return FlowControl._extract_csv_data(data, query)

    @staticmethod
    def _extract_csv_data(data: List[List[str]], query: str) -> List[Any]:
        """Extracts data from CSV based on query (column name or index as string)."""
        headers = data[0]
        rows = data[1:]
        # Try to use as column name first
        if query in headers:
            col_idx = headers.index(query)
            return [row[col_idx] for row in rows if len(row) > col_idx and row[col_idx]]
        # Try to use as integer index
        try:
            idx = int(query)
            if idx >= len(headers):
                raise OpticsError(Code.E0403, message="Index out of range.")
            return [row[idx] for row in rows if len(row) > idx and row[idx]]
        except ValueError:
            pass
        raise OpticsError(Code.E0403, message=f"Query '{query}' must be a column name or integer index present in the CSV.")

    @defines_variable
    @substitutes_own_vars
    @raw_params(0)
    def evaluate(self, param1: str, param2: str) -> Any:
        """Evaluates an expression and stores the result in session.elements.

        :param param1: Variable name to store the result under, e.g. ``${result}``.
        :param param2: Expression to evaluate; ``${var}`` refs are substituted first,
            then run through a restricted eval (arithmetic, comparisons, ternary).
        :return: The evaluated result (also stored as a string in session.elements).
        """
        self._ensure_session()
        if self.session is None:
            raise OpticsError(Code.E0501, message=NO_SESSION_PRESENT)
        var_name = self._extract_variable_name(param1)
        runner_elements = self._get_or_create_session_elements()
        result = self._compute_expression(param2)
        runner_elements.remove_element(var_name)
        runner_elements.add_element(var_name, str(result))
        return result

    def _extract_variable_name(self, param1: str) -> str:
        """Extracts and cleans the variable name from param1."""
        var_name = param1.strip()
        if var_name.startswith("${") and var_name.endswith("}"):
            return var_name[2:-1].strip()
        internal_logger.warning(
            f"[EVALUATE] Expected param1 in format '${{name}}', got '{param1}'. Using as is."
        )
        return var_name

    def _compute_expression(self, param2: str) -> Any:
        """Computes an expression by resolving variables and evaluating it."""
        if self.session is None:
            raise OpticsError(Code.E0501, message=NO_SESSION_PRESENT)
        runner_elements = getattr(self.session, "elements", None)
        if not isinstance(runner_elements, ElementData):
            raise OpticsError(Code.E0702, message=NO_SESSION_ELEMENT_PRESENT)

        def replace_var(ref: utils.VarRef) -> str:
            value = runner_elements.get_first(ref.name)
            if value is None:
                raise OpticsError(Code.E0702, message=f"Variable '{ref.name}' not found in elements.")
            return str(value)

        return self._safe_eval(utils.substitute_vars(param2, replace_var))

    def _safe_eval(self, text: str, values: dict[str, Any] | None = None) -> Any:
        """Evaluate ``text`` with session variables and ``values`` as names, through the restricted evaluator."""
        if self.session is None:
            raise OpticsError(Code.E0501, message=NO_SESSION_PRESENT)
        runner_elements = getattr(self.session, "elements", None)
        if not isinstance(runner_elements, ElementData):
            raise OpticsError(Code.E0702, message=NO_SESSION_ELEMENT_PRESENT)
        return expression.evaluate(text, {**{k: v[0] for k, v in runner_elements.elements.items() if v}, **(values or {})})

    def _detect_date_format(self, date_str: str) -> str:
        """Detect the format of the input date string."""
        common_formats = [
            "%m/%d/%Y",  # 04/25/2025
            "%d/%m/%Y",  # 25/04/2025
            "%Y-%m-%d",  # 2025-04-25
            "%d-%m-%Y",  # 25-04-2025
            "%Y/%m/%d",  # 2025/04/25
        ]
        for fmt in common_formats:
            try:
                datetime.strptime(date_str, fmt)
                return fmt
            except ValueError:
                continue
        raise OpticsError(Code.E0403, message=f"Unable to detect date format for input: {date_str}")

    @defines_variable
    @raw_params(0)
    def date_evaluate(
        self, param1: str, param2: str, param3: str, param4: Optional[str] = "%d %B"
    ) -> str:
        """
        Evaluates a date expression based on an input date and stores the result in session.elements.

        :param param1: The variable name (placeholder) where the evaluated date result will be stored.
        :param param2: The input date string (e.g., ``"04/25/2025"`` or ``"2025-04-25"``). Format is auto-detected.
        :param param3: The date expression to evaluate, such as ``"+1 day"``, ``"-2 days"``, or ``"today"``.
        :param param4: The output format for the evaluated date (default is ``"%d %B"``, e.g., ``"26 April"``).
        :returns: The resulting evaluated and formatted date string.
        :raises OpticsError: If the session is not present, the input date format cannot be detected,
            or the expression format is invalid.

        Example:

            date_evaluate("tomorrow", "04/25/2025", "+1 day")
            -> Stores "26 April" in session.elements["tomorrow"]
        """
        self._ensure_session()
        if self.session is None:
            raise OpticsError(Code.E0501, message=NO_SESSION_PRESENT)

        var_name = self._extract_variable_name(param1)
        input_date = param2.strip()
        expression = param3.strip()
        output_format = param4 or "%d %B"

        # Detect input format
        input_format = self._detect_date_format(input_date)

        # Parse current date
        base_date = datetime.strptime(input_date, input_format)

        # Parse and apply expression
        expr = expression.lower()
        if expr.startswith("+"):
            number, unit = expr[1:].split()
            number = int(number)
            if unit.startswith("day"):
                base_date += timedelta(days=number)
            else:
                raise OpticsError(Code.E0403, message=f"Unsupported unit in expression: {unit}")
        elif expr.startswith("-"):
            number, unit = expr[1:].split()
            number = int(number)
            if unit.startswith("day"):
                base_date -= timedelta(days=number)
            else:
                raise OpticsError(Code.E0403, message=f"Unsupported unit in expression: {unit}")
        elif expr in ("today", "now"):
            pass  # No change
        else:
            raise OpticsError(Code.E0403, message=f"Unsupported expression format: {expression}")

        # Format result
        result = base_date.strftime(output_format)

        # Store in session.elements
        self._get_or_create_session_elements().store(var_name, result)
        return result

    def invoke_api(self, api_identifier: str) -> dict[str, Any]:
        """Invokes an API call based on a definition from the session's API data.

        :param api_identifier: API to call, in ``collection.api_name`` form.
        :return: ``status_code``, ``headers``, ``body`` and ``elapsed_ms`` of the response.
        """
        internal_logger.debug(f"[INVOKE_API] Called with api_identifier={api_identifier}")
        self._ensure_session()
        if self.session is None:
            raise OpticsError(Code.E0702, message=NO_SESSION_PRESENT)
        collection_name, api_name = self._parse_api_identifier(api_identifier)
        internal_logger.debug(f"[INVOKE_API] Parsed collection_name={collection_name}, api_name={api_name}")
        collection = self._get_api_collection(collection_name)
        internal_logger.debug(f"[INVOKE_API] Retrieved API collection: {collection_name}")
        api_def = self._get_api_definition(collection, api_name)
        internal_logger.debug(f"[INVOKE_API] Retrieved API definition: {api_name}")

        url, headers, body = self._prepare_request_details(collection, api_def)
        internal_logger.debug(f"[INVOKE_API] Prepared request details: url={url}, headers={headers}, body={body}, method={api_def.request.method}")
        response = self._execute_request(url, headers, body, api_def.request.method)
        internal_logger.debug(f"[INVOKE_API] Received response: status_code={response.status_code}")
        self._process_response(response, api_def)
        internal_logger.debug(f"[INVOKE_API] Finished processing response for API: {api_name}")
        return {
            "status_code": response.status_code,
            "headers": dict(response.headers),
            "body": self._response_body(response),
            "elapsed_ms": round(response.elapsed.total_seconds() * 1000, 3),
        }

    def _response_body(self, response: requests.Response) -> Any:
        """Parsed JSON body, or the raw text when the response is not JSON."""
        try:
            return response.json()
        except ValueError:
            return response.text

    def _parse_api_identifier(self, identifier: str) -> Tuple[str, str]:
        """Parses 'collection.api' into a tuple."""
        parts = identifier.split(".", 1)
        if len(parts) != 2:
            raise OpticsError(Code.E0403, message=f"Invalid API identifier format: '{identifier}'. Expected 'collection.api_name'.")
        return parts[0], parts[1]

    def _get_api_collection(self, name: str):
        """Retrieves an API collection from the session."""
        if self.session is None:
            raise OpticsError(Code.E0702, message=NO_SESSION_PRESENT)
        if not isinstance(self.session.apis, ApiData):
            raise OpticsError(Code.E0702, message="session instance does not have a valid 'apis' attribute.")
        collection = self.session.apis.collections.get(name)
        if not collection:
            raise OpticsError(Code.E0601, message=f"API collection '{name}' not found.")
        return collection

    def _get_api_definition(self, collection, name: str):
        """Retrieves a specific API definition from a collection."""
        api_def = collection.apis.get(name)
        if not api_def:
            raise OpticsError(Code.E0601, message=f"API '{name}' not found in collection '{collection.name}'.")
        return api_def

    def _prepare_request_details(
        self, collection, api_def
    ) -> Tuple[str, dict[str, str], Optional[Any]]:
        """Constructs the full request URL, headers, and body."""
        base_url = collection.base_url
        endpoint = self._resolve_placeholders(api_def.endpoint)
        if endpoint.startswith(("http://", "https://")):
            full_url = endpoint
        else:
            full_url = f"{base_url}{endpoint}"

        headers = {**collection.global_headers, **api_def.request.headers}
        resolved_headers = self._resolve_placeholders(headers)

        body = self._resolve_placeholders(api_def.request.body)
        return full_url, resolved_headers, body

    def _resolve_placeholders(self, data: Any) -> Any:
        """Recursively resolves ${...} placeholders in strings, dicts, or lists."""
        if isinstance(data, str):
            return utils.substitute_vars(data, lambda ref: self._resolve_param(f"${{{ref.name}}}"))
        if isinstance(data, dict):
            return {k: self._resolve_placeholders(v) for k, v in data.items()}
        if isinstance(data, list):
            return [self._resolve_placeholders(i) for i in data]
        return data

    def _execute_request(
    self, url: str, headers: dict, body: Optional[Any], method: str
    ) -> requests.Response:
        """Executes the HTTP request and returns the response."""
        try:
            config_handler = self.config_handler
            execution_output_path = config_handler.config.execution_output_path
            api_log_dir = execution_output_path

            api_log_file_path = None
            api_har_file_path = None
            if api_log_dir:
                os.makedirs(api_log_dir, exist_ok=True)
                api_log_file_path = os.path.join(api_log_dir, "api_details.log")
                api_har_file_path = os.path.join(api_log_dir, "api_details.har")

            start_time = datetime.now(timezone.utc)
            response = requests.request(
                method, url, headers=headers, json=body, timeout=30
            )
            time_taken = response.elapsed.total_seconds() * 1000

            if api_log_dir and api_log_file_path is not None:
                self._write_api_log(
                    api_log_file_path, method, url, headers, body, response
                )
                self._write_api_har(
                    api_har_file_path,
                    start_time,
                    time_taken,
                    method,
                    url,
                    headers,
                    body,
                    response,
                )

            return response
        except requests.RequestException as e:
            internal_logger.error(f"API request to {url} failed: {e}")
            raise OpticsError(Code.E0401, message=f"API request to {url} failed: {plain(e)}", cause=e)

    def _write_api_log(self, log_file_path, method, url, headers, body, response):
        """Append one JSON object per call, so no URL or response text can forge another record."""
        record = {
            "timestamp": datetime.now().isoformat(),
            "method": method,
            "url": url,
            "headers": headers,
            "body": body,
            "status_code": response.status_code,
            "response_body": self._response_body(response),
        }
        with open(log_file_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(record, default=str) + "\n")

    def _write_api_har(
        self,
        har_file_path,
        start_time,
        time_taken,
        method,
        url,
        headers,
        body,
        response,
    ):
        """Writes API request/response details to a HAR file."""
        parsed_url = urlparse(url)
        query_string = [{"name": k, "value": v} for k, v in parse_qsl(parsed_url.query)]

        post_data = None
        request_body_size = 0
        if body:
            request_body_text = json.dumps(body)
            request_body_size = len(request_body_text.encode("utf-8"))
            post_data = {"mimeType": "application/json", "text": request_body_text}

        har_entry = {
            "startedDateTime": start_time.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z",
            "time": time_taken,
            "request": {
                "method": method,
                "url": url,
                "httpVersion": "HTTP/1.1",
                "cookies": [],
                "headers": [{"name": k, "value": v} for k, v in headers.items()],
                "queryString": query_string,
                "postData": post_data,
                "headersSize": -1,
                "bodySize": request_body_size,
            },
            "response": {
                "status": response.status_code,
                "statusText": response.reason,
                "httpVersion": "HTTP/1.1",
                "cookies": [],
                "headers": [
                    {"name": k, "value": v} for k, v in response.headers.items()
                ],
                "content": {
                    "size": len(response.content),
                    "mimeType": response.headers.get("Content-Type", ""),
                    "text": response.text,
                },
                "redirectURL": response.headers.get("Location", ""),
                "headersSize": -1,
                "bodySize": len(response.content),
            },
            "cache": {},
            "timings": {
                "wait": response.elapsed.total_seconds() * 1000,
                "send": -1,
                "receive": -1,
            },
        }

        _append_har_entry(har_file_path, json.dumps(har_entry).encode("utf-8"))

    def _process_response(self, response: requests.Response, api_def) -> None:
        """Extracts data from the response and saves it to session elements."""
        if not api_def.expected_result:
            internal_logger.debug("No expected_result defined in API definition.")
            return

        expected_status = api_def.expected_result.expected_status
        if expected_status is not None and response.status_code != expected_status:
            raise AssertionError(
                f"API '{api_def.name}' returned status {response.status_code}, expected {expected_status}."
            )

        if self.session is None:
            raise ValueError(NO_SESSION_PRESENT)
        response_data = self._parse_response_json(response)
        if response_data is None:
            return

        self._log_extraction_attempt(api_def.expected_result.extract)

        if api_def.expected_result.extract:
            self._extract_values_from_response(response_data, api_def.expected_result.extract)

        if api_def.expected_result.jsonpath_assertions:
            self._evaluate_jsonpath_assertions(
                response_data, api_def.expected_result.jsonpath_assertions
            )

    def _parse_response_json(self, response: requests.Response):
        """Parses response as JSON, returns None if parsing fails."""
        try:
            return response.json()
        except json.JSONDecodeError as e:
            internal_logger.warning(
                f"API response is not valid JSON; cannot extract values. Error: {e}"
            )
            raise OpticsError(Code.E0403, message=f"API response is not valid JSON: {plain(e)}", cause=e)

    def _log_extraction_attempt(self, extract_paths):
        """Logs the extraction attempt based on available paths."""
        if not extract_paths:
            internal_logger.debug("No extraction paths defined in API definition.")
        else:
            internal_logger.debug(
                f"Attempting to extract values using paths: {extract_paths}"
            )

    def _extract_values_from_response(self, response_data, extract_paths):
        """Extracts values from response data using specified paths."""
        for element_name, path in extract_paths.items():
            self._extract_and_store_single_value(response_data, element_name, path)

        internal_logger.debug(
            f"Current session elements after extraction: {self.session.elements}"
        )

    def _extract_and_store_single_value(self, response_data, element_name: str, path: str):
        """Extracts a single value and stores it in session elements."""
        value = self._extract_from_json(response_data, path)
        if value is not None:
            runner_elements = self._get_or_create_session_elements()
            runner_elements.remove_element(element_name)
            runner_elements.add_element(element_name, value)
            internal_logger.debug(
                f"Extracted '{element_name}' = '{value}' from response."
            )
        else:
            internal_logger.warning(
                f"Could not extract '{element_name}' using path '{path}'."
            )

    def _get_or_create_session_elements(self) -> ElementData:
        """Gets session elements or creates if not properly initialized.

        `optics serve` creates every session with `elements=None` and offers no way to fill
        it, so raising here left `Invoke API` unusable there — its `extract` had nowhere to
        put a value. `TestRunner` already substitutes an empty `ElementData` in the same
        case, so creating one is the reading the runner has always taken.
        """
        runner_elements = getattr(self.session, "elements", None)
        if not isinstance(runner_elements, ElementData):
            runner_elements = ElementData()
            self.session.elements = runner_elements
        return runner_elements

    def _evaluate_jsonpath_assertions(
    self, data: Any, assertions: list[dict[str, Any]]
    ) -> None:
        """Evaluates JSONPath assertions against the response data."""
        for assertion in assertions:
            path = assertion.get("path")
            condition = assertion.get("condition")
            if not path or not condition:
                internal_logger.warning(
                    f"Skipping malformed JSONPath assertion: {assertion}"
                )
                continue

            try:
                jsonpath_expr = jsonpath_parse(path)
                match = jsonpath_expr.find(data)

                if not match:
                    internal_logger.warning(f"[JSONPATH] JSONPath '{path}' found no match.")
                    raise AssertionError(f"JSONPath '{path}' found no match.")

                matched_value = match[0].value
                if not expression.check_condition(condition, matched_value):
                    internal_logger.warning(f"[JSONPATH] JSONPath assertion failed: Path '{path}', Condition '{condition}', Matched value '{matched_value}'.")
                    raise AssertionError(
                        f"JSONPath assertion failed: Path '{path}', Condition '{condition}', Matched value '{matched_value}'."
                    )
                internal_logger.debug(
                    f"JSONPath assertion passed: Path '{path}', Condition '{condition}'."
                )
            except OpticsError:
                raise
            except Exception as e:
                raise AssertionError(
                    f"Error evaluating JSONPath assertion {assertion}: {e}"
                ) from e

    def _extract_from_json(self, data: Any, path: str) -> Optional[Any]:
        """Extracts a value using a JSONPath expression, or the bare ``a.b`` form."""
        expression = path if path.lstrip().startswith("$") else f"$.{path}"
        try:
            matches = jsonpath_parse(expression).find(data)
        except Exception as e:  # noqa: BLE001 - a bad path is a definition error, not a crash
            internal_logger.warning(f"Invalid extract path '{path}': {e}")
            return None
        if not matches:
            internal_logger.warning(f"Extract path '{path}' matched nothing in the response.")
            return None
        return matches[0].value
