import collections
import shlex
import time
import json
from functools import partial
from typing import Callable, Optional, Any, Tuple, List, Dict
from optics_framework.common.logging_config import internal_logger, register_marked_secret
from optics_framework.common.optics_builder import OpticsBuilder
from optics_framework.common.strategies import NoLocatorSource, StrategyManager, changing_screen, one_capture_per_source
from optics_framework.common.elementsource_interface import ScreenPoint
from optics_framework.common.base_factory import InstanceFallback
from optics_framework.common import keyword_outcome, test_context, utils
from optics_framework.common.agent_core import bind, runner_params, visible_params
from optics_framework.common.ai_self_heal import (
    VALUE_PLACEHOLDER, AISelfHealHandler, HealContext, HealKeywordSpec, KeywordExecResult,
)
from optics_framework.common.error import Code, ElementNotFound, OpticsError, element_label
from optics_framework.common.popup_guard import PopupGuard, PopupIO, PopupRun, Verdict
from optics_framework.common.popup_screen import PopupScreen
from optics_framework.common.screen_snapshot import read_screen
from .verifier import Verifier

# Class/tag substrings (case-insensitive) that identify a scrollable dropdown-list
# container in a UI hierarchy dump, used by select_dropdown_option's scroll-to-find path.
_DROPDOWN_LIST_CLASS_TOKENS = (
    # Android
    "listview", "recyclerview", "scrollview", "spinner", "gridview", "viewpager",
    "dropdownlistview", "listpopupwindow", "menupopup",
    # iOS
    "pickerwheel", "table", "collectionview", "menu", "picker",
)

# Fraction of the dropdown container's height swiped per scroll step. Kept below 1.0 so
# consecutive scans overlap and a fast/long swipe can't skip past an unscanned option row.
_DROPDOWN_SWIPE_OVERLAP_FACTOR = 0.5

# Per-check timeout for assert_visibility while polling for the option, matching the budget
# scroll_until_element_appears/swipe_until_element_appears use for the same purpose.
_DROPDOWN_OPTION_CHECK_TIMEOUT = "3"


def _parse_aoi_param(param: Any, default_value: float) -> float:
    if param is None or str(param).strip() in ('', 'None', 'none'):
        return default_value
    return float(param)


def _maybe_save_aoi_screenshot(
    screenshot_np: Any,
    aoi_x: float, aoi_y: float, aoi_width: float, aoi_height: float,
    execution_dir: str,
    func_name: str,
) -> None:
    annotated = utils.annotate_aoi_region(screenshot_np, aoi_x, aoi_y, aoi_width, aoi_height)
    utils.save_screenshot(annotated, f"{func_name}_with_aoi", output_dir=execution_dir)


def _locate_element(
    strategy_manager: StrategyManager,
    element: Any,
    aoi_x: float, aoi_y: float, aoi_width: float, aoi_height: float,
    index: int,
    is_aoi_used: bool,
):
    if is_aoi_used:
        return strategy_manager.locate(element, aoi_x, aoi_y, aoi_width, aoi_height, index=index)
    return strategy_manager.locate(element, index=index)


def _save_annotated_for_result(
    result: Any,
    screenshot_np: Any,
    execution_dir: str | None,
    func_name: str,
) -> None:
    annotated = getattr(result, "annotated_frame", None)
    if not execution_dir:
        return
    if annotated is not None:
        utils.save_screenshot(
            annotated,
            f"{func_name}_image_detection_result",
            output_dir=execution_dir,
            time_stamp=utils.get_timestamp(),
        )
        return
    if result.is_coordinates or screenshot_np is None:
        return
    element_source = getattr(result.strategy, "element_source", None)
    if element_source is None or not hasattr(element_source, "get_bbox_for_element"):
        return
    framed = utils.boxed_frame(screenshot_np, element_source, lambda: [element_source.get_bbox_for_element(result.value)])
    if framed is None:
        return
    utils.save_screenshot(
        framed,
        f"{func_name}_element_detection_result",
        output_dir=execution_dir,
        time_stamp=utils.get_timestamp(),
    )


_POPUP_STOPS = (Code.E0206, Code.E0407, Code.E0408)


def _is_covered(located: Any, allow_covered: bool) -> bool:
    return isinstance(located, ScreenPoint) and located.covered and not allow_covered


def _not_located(element: Any, error: Optional[OpticsError]) -> OpticsError:
    """The error for an element no strategy located: the strategy layer's own when it already says why."""
    if isinstance(error, ElementNotFound) or (error is not None and error.code in (Code.E0205, *_POPUP_STOPS)):
        return error
    return ElementNotFound(element, cause=error)


def _keyword_name(func_name: str) -> str:
    return func_name.replace("_", " ").title()


def _refuse_covered(located: Any, element: Any, allow_covered: bool) -> None:
    """Fail a web point that something else covers, so the next strategy's result gets a try."""
    if _is_covered(located, allow_covered):
        raise OpticsError(Code.E0201, message=f"'{element}' is covered by another element on the page.")


def _bounds_area(bounds: Optional[dict]) -> int:
    """
    indirect helper for `select_dropdown_option()`

    calculates bounded area for an element
    """
    if not bounds:
        return 0
    try:
        return max(0, bounds["x2"] - bounds["x1"]) * max(0, bounds["y2"] - bounds["y1"])
    except (KeyError, TypeError):
        return 0


def _find_dropdown_container(new_elements: List[dict]) -> Optional[dict]:
    """
    used with `select_dropdown_option()

    pick the largest list like container from the newly appeared elements

    a union bounding box of all new elements is intentionally not used because pressing the
    dropdown trigger can also reveal unrelated elements, not just the option list
    """
    candidates = []
    for el in new_elements:
        if not isinstance(el, dict) or not el.get("bounds"):
            continue
        extra = el.get("extra") or {}
        class_or_tag = (extra.get("class") or extra.get("tag") or "").lower()
        if any(t in class_or_tag for t in _DROPDOWN_LIST_CLASS_TOKENS):
            candidates.append(el)
    if not candidates:
        return None
    return max(candidates, key=lambda e: _bounds_area(e.get("bounds")))


def _unsupported(error: Exception) -> bool:
    return isinstance(error, OpticsError) and error.code == Code.E0105


def _raise_option_not_found(dropdown_element: str, option: str, interactive: List[dict]) -> None:
    """
    helper for `select_dropdown_option()
    """
    available_texts = [
        el.get("text") for el in interactive if isinstance(el, dict) and el.get("text")
    ]
    raise OpticsError(
        Code.E0201,
        message=(
            f"Option '{option}' not found in dropdown '{dropdown_element}'. "
            f"Available options: {available_texts}"
        ),
    )


MAX_REPEAT = 100
_MAX_SCREEN_PX = 16_384


def _bounded(value: Any, name: str, low: int, high: int, parse: Callable[[Any], Any] = int) -> Any:
    """``value`` parsed by ``parse``; E0403 unless it is a number from ``low`` to ``high`` (NaN never is)."""
    try:
        number = parse(value)
    except (TypeError, ValueError):
        number = None
    if number is None or not low <= number <= high:
        raise OpticsError(Code.E0403, message=f"'{name}' must be a number from {low} to {high}, got '{str(value)[:20]}'")
    return number


def _repeat(value: Any) -> int:
    return _bounded(value, "repeat", 1, MAX_REPEAT)


def _pixel(value: Any, name: str) -> int:
    return _bounded(value, name, 0, _MAX_SCREEN_PX)


def _offset(value: Any, name: str) -> int:
    return _bounded(value, name, -_MAX_SCREEN_PX, _MAX_SCREEN_PX)


def _percent(value: Any, name: str, parse: Callable[[Any], Any] = float) -> Any:
    return _bounded(value, name, 0, 100, parse)


class _HealProviders:
    """Screenshot, page-source and screen-element providers for one AI self-heal attempt."""

    def __init__(self, seed_png: bytes, action_keyword: "ActionKeyword") -> None:
        self._seed_png: Optional[bytes] = seed_png
        self._last_png: bytes | None = seed_png
        self._action_keyword = action_keyword

    def screenshot(self) -> Optional[bytes]:
        if self._seed_png is not None:
            png, self._seed_png = self._seed_png, None
            return png
        try:
            self._last_png = utils.encode_numpy_to_png_bytes(self._action_keyword.strategy_manager.capture_screenshot())
        except Exception:  # noqa: BLE001 - best-effort re-capture
            return None
        return self._last_png

    def snapshot(self) -> list[dict] | None:
        return read_screen(self._action_keyword, self._last_png)

    def pagesource(self) -> Optional[str]:
        try:
            ps = self._action_keyword.strategy_manager.capture_pagesource()
            return utils.strip_page_source(ps[0]) if ps else None
        except OpticsError:
            return None


class ActionKeyword:
    """
    High-Level API for Action Keywords

    This class provides functionality for managing action keywords related to applications,
    including pressing elements, scrolling, swiping, and text input.
    """
    SCREENSHOT_DISABLED_MSG = "Screenshot taking is disabled, not possible to locate element."
    XPAHT_NOT_SUPPORTED_MSG = "XPath is not supported for vision based search."

    def __init__(self, builder: OpticsBuilder):
        self.driver: InstanceFallback = builder.get_driver()
        self.element_source: InstanceFallback = builder.get_element_source()
        self.image_detection: Optional[InstanceFallback] = builder.get_image_detection()
        self.text_detection: Optional[InstanceFallback] = builder.get_text_detection()
        self.verifier = Verifier(builder)
        # Unwrap InstanceFallback to pass current_instance to StrategyManager

        self.strategy_manager = StrategyManager(
            self.element_source, self.text_detection, self.image_detection
        )
        session_config = builder.session_config
        self.capture_output_dir = session_config.capture_dir
        self._own_popup_run = PopupRun()
        self._module_runner: Optional[Callable[[str], Any]] = None
        self._popup_source_driver: Any = None
        self._popup = PopupGuard(lambda: session_config.popup_rules, self._popup_io(), self._popup_run)
        # AI self-heal (last-resort fallback). Inert unless explicitly toggled on AND an
        # llm_models entry is enabled. Fetching the LLM is guarded: a misconfiguration
        # (e.g. the engine's optional extra missing) must disable the feature, not
        # crash the run. A config error (E0501), such as a bad credentials_path, still stops it.
        self.ai_self_heal_enabled = bool(getattr(builder.session_config, "ai_self_heal", False))
        self._llm = None
        if self.ai_self_heal_enabled:
            try:
                self._llm = builder.get_llm()
            except Exception as e:  # noqa: BLE001 - degrade to inert
                if isinstance(e, OpticsError) and e.code is Code.E0501:
                    raise
                internal_logger.warning(
                    "AI self-heal enabled but no usable LLM (%s); self-heal disabled.", e
                )
        self._ai_healer: Optional[AISelfHealHandler] = None
        # Breadcrumbs of recently-succeeded keywords, fed to the LLM as context on heal.
        self._recent_steps: "collections.deque[Tuple[str, list]]" = collections.deque(maxlen=10)
        self._last_heal_info: Optional[Dict[str, Any]] = None
        self._heal_popup_stop: Optional[OpticsError] = None
        self._heal_dispatch: Dict[str, Callable] = {
            "press_element": self.press_element,
            "enter_text": self.enter_text,
            "scroll": self.scroll,
            "swipe_by_percentage": self.swipe_by_percentage,
            "press_keycode": self.press_keycode,
            "press_by_percentage": self.press_by_percentage,
        }

    def _record_successful_step(self, func_name: str, element: Any, args: tuple, value: str | None = None) -> None:
        typed = [VALUE_PLACEHOLDER] if value is not None else []
        self._recent_steps.append((func_name, [str(element), *map(str, args), *typed]))

    def _ai_self_heal(
        self, element: Any, func_name: str, intent_args: tuple, screenshot_np: Any, value: str | None = None
    ) -> bool:
        """Last-resort AI recovery after every locate strategy failed. Returns True if healed.

        Fully inert (returns False, no LLM call) when the toggle is off, no LLM is enabled, or
        no screenshot is available. On any problem it returns False so the caller re-raises the
        original element-not-found error and the param-fallback ladder continues. The one exception
        is a popup that ends the step or run: that error ends the heal and is raised as it is.
        """
        if not self._ai_self_heal_ready(screenshot_np):
            return False
        try:
            seed_png = utils.encode_numpy_to_png_bytes(screenshot_np)
        except ValueError:
            return False

        providers = _HealProviders(seed_png, self)
        ctx = HealContext(
            intent_keyword=func_name,
            intent_params=[str(a) for a in intent_args],
            value=value,
            element=str(element),
            element_name=test_context.element_names.get({}).get(str(element), ""),
            recent_steps=list(self._recent_steps),
            failed_strategies=sorted(
                {type(s).__name__ for s in self.strategy_manager.locator_strategies}
            ),
        )
        if self._ai_healer is None:
            self._ai_healer = AISelfHealHandler(
                self._llm,
                keyword_executor=self._heal_execute,
                keyword_catalog=self._heal_catalog,
                curate=True,
            )
        internal_logger.info("AI self-heal: attempting recovery for '%s' on '%s'", func_name, element)
        with changing_screen():
            result = self._ai_healer.heal(
                ctx, providers.screenshot, providers.pagesource, snapshot_provider=providers.snapshot
            )
        stop, self._heal_popup_stop = self._heal_popup_stop, None
        if stop is not None:
            raise stop
        self._log_heal_outcome(result, func_name, element, intent_args, value)
        return result.ok

    def _ai_self_heal_ready(self, screenshot_np: Any) -> bool:
        """True only when self-heal can run: toggle on, an LLM instance, and a screenshot."""
        if not self.ai_self_heal_enabled or self._llm is None or screenshot_np is None:
            return False
        return bool(getattr(self._llm, "instances", None))

    def _log_heal_outcome(self, result: Any, func_name: str, element: Any, args: tuple, value: str | None) -> None:
        """Log the heal result and, on success, record it for reporting.

        Exposes ``_last_heal_info`` with a human-readable ``summary`` and a structured
        ``suggested_steps`` list that reporting layers (HTTP/MCP) can persist as
        replacement steps. ``suggested_steps`` is the clean replayable recovery, written as CSV steps.
        """
        if not result.ok:
            internal_logger.info(
                "AI self-heal: could not recover '%s': %s", func_name, result.message
            )
            return
        action = result.action
        kw = action.keyword if action else "?"
        internal_logger.info("AI self-heal: recovered '%s' via keyword '%s'", func_name, kw)
        self._record_successful_step(func_name, element, args, value)
        steps = []
        for name, params in result.suggested_steps:
            fn = self._heal_dispatch[name]
            steps.append((name, runner_params(fn, bind(fn, params, *params[:1], drop_first=params[:1]))))
        rendered = [self._render_heal_step(name, params) for name, params in steps]
        if value is not None:
            steps = [(name, [value if p == VALUE_PLACEHOLDER else p for p in params]) for name, params in steps]
        if rendered:
            plural = "s" if len(rendered) != 1 else ""
            summary = (
                f"AI self-heal recovered '{func_name}' after {len(rendered)} "
                f"step{plural}: {'; '.join(rendered)}"
            )
        else:
            summary = f"AI self-heal recovered '{func_name}' (goal already satisfied)"
        self._last_heal_info = {
            "summary": summary,
            "suggested_steps": [
                {"keyword": name, "params": list(params)} for name, params in steps
            ],
        }

    @staticmethod
    def _render_heal_step(keyword: str, params: List[str]) -> str:
        """Human-readable 'keyword param1 param2' line for the summary string."""
        return keyword if not params else f"{keyword} {' '.join(str(p) for p in params)}"

    def _pop_last_heal_info(self) -> Optional[Dict[str, Any]]:
        """Return and clear the heal info of the most recent call."""
        info, self._last_heal_info = self._last_heal_info, None
        return info

    # -- Self-heal keyword executor and catalog --------------------------------

    def _heal_execute(self, line: str) -> KeywordExecResult:
        """Keyword executor for self-heal: parse and run one keyword, returning a KeywordExecResult.

        Dispatches through the same public keyword methods (and therefore the same
        locate ladder), with self-heal temporarily disabled so a heal cannot recurse.
        """
        try:
            tokens = shlex.split(line, posix=True)
        except ValueError as exc:
            return KeywordExecResult(ok=False, message=f"Parse error: {exc}")
        if not tokens:
            return KeywordExecResult(ok=False, message="Empty keyword line")

        keyword_name = tokens[0]
        params = tokens[1:]

        method = self._heal_dispatch.get(keyword_name)
        if method is None:
            return KeywordExecResult(ok=False, message=f"Unknown keyword: {keyword_name}")

        try:
            bound = bind(method, params, *params[:1], drop_first=params[:1])
        except ValueError as exc:
            return KeywordExecResult(ok=False, message=str(exc))
        try:
            # Dispatched keywords go through the same locate ladder; self-heal is
            # temporarily disabled so a heal cannot recurse into itself.
            original_enabled = self.ai_self_heal_enabled
            self.ai_self_heal_enabled = False
            try:
                method(**bound)
            finally:
                self.ai_self_heal_enabled = original_enabled
            return KeywordExecResult(ok=True)
        except OpticsError as exc:
            if exc.code in _POPUP_STOPS:
                self._heal_popup_stop = exc
                raise
            return KeywordExecResult(ok=False, message=str(exc.message))
        except Exception as exc:  # noqa: BLE001 - never crash the heal loop
            return KeywordExecResult(ok=False, message=str(exc))

    def _heal_catalog(self) -> List[HealKeywordSpec]:
        """Return the keyword catalog for the self-healer (focused subset with signatures)."""
        return [
            HealKeywordSpec(name=name, signature=self._heal_keyword_signature(name, method))
            for name, method in self._heal_dispatch.items()
        ]

    @staticmethod
    def _heal_keyword_signature(name: str, method: Callable) -> str:
        """Build a ghost-text signature like ``press_element <element> [repeat] [offset_x]``."""
        params = (f"<{p.name}>" if p.default is p.empty else f"[{p.name}]" for p in visible_params(method))
        return " ".join([name, *params])

    def _capture_screenshot_safe(self) -> Any:
        """Capture a screenshot, or None on failure or when neither saved captures nor AI self-heal need it."""
        if (self.capture_output_dir is None and self._llm is None) or not self.strategy_manager.sees_screen:
            return None
        try:
            return self.strategy_manager.capture_screenshot()
        except Exception as e:
            internal_logger.warning(f"Screenshot capture failed, continuing without it: {e}")
            return None

    def _save_screenshot_if_available(self, screenshot_np: Any, name: str) -> None:
        """Save a screenshot only if one was successfully captured."""
        if screenshot_np is not None and self.capture_output_dir is not None:
            utils.save_screenshot(screenshot_np, name, output_dir=self.capture_output_dir)

    def _locate_and_act(
        self,
        element: Any,
        func_name: str,
        act: Callable[[Any], Any],
        intent_args: tuple = (),
        index: str = "0",
        aoi: Tuple[str, str, str, str] = ("0", "0", "100", "100"),
        allow_covered: bool = False,
        value: str | None = None,
    ) -> Any:
        """Locate ``element`` through the strategy ladder and run ``act`` on it.

        This is fallback level 2, shared by every locate-based keyword. ``act`` receives
        each successful locate value in strategy-priority order (XPath -> text -> OCR ->
        image); the first call that returns without raising wins. When no strategy yields
        a result, or every ``act`` call raises, AI self-heal gets one chance before
        E0201/X0201 is raised.

        ``intent_args`` are the keyword's action parameters (everything after the
        element, minus locate-tuning params); they feed the self-heal breadcrumbs.
        ``value`` is the text the keyword types: self-heal may choose where it goes, but never sees it.
        A covered point is skipped like a failed action; a keyword that only reads it sets ``allow_covered``.

        With popup rules set, a rule that checks before each step runs first, and a lookup that fails is checked
        for a popup before self-heal: one that a rule dismisses makes the step look again.
        """
        self.strategy_manager.require_screen()
        aoi_x = _parse_aoi_param(aoi[0], 0)
        aoi_y = _parse_aoi_param(aoi[1], 0)
        aoi_width = _parse_aoi_param(aoi[2], 100)
        aoi_height = _parse_aoi_param(aoi[3], 100)
        is_aoi_used = not (aoi_x == 0 and aoi_y == 0 and aoi_width == 100 and aoi_height == 100)
        lookup_index = int(index)
        if self._popup.active:
            self._popup.begin_step(func_name, element)
            self._raise_popup_stop(self._popup.before_step())
        while True:
            with one_capture_per_source():
                screenshot_np = self._capture_screenshot_safe()
                if is_aoi_used and screenshot_np is not None and self.capture_output_dir is not None:
                    _maybe_save_aoi_screenshot(
                        screenshot_np, aoi_x, aoi_y, aoi_width, aoi_height,
                        self.capture_output_dir, func_name,
                    )
                self._save_screenshot_if_available(screenshot_np, f"pre_{func_name}")
                results = _locate_element(
                    self.strategy_manager, element,
                    aoi_x, aoi_y, aoi_width, aoi_height, lookup_index, is_aoi_used,
                )
                try:
                    return self._act_until_success(
                        results, act, element, func_name, intent_args, screenshot_np, allow_covered=allow_covered, value=value
                    )
                except OpticsError as e:
                    if e.code != Code.E0409:
                        raise

    def _act_on(
        self, result: Any, act: Callable[[Any], Any], element: Any, func_name: str, allow_covered: bool
    ) -> tuple[Any, Exception | None]:
        """``act``'s return value on one locate result, or the error that sends the caller to the next result."""
        try:
            _refuse_covered(result.value, element, allow_covered)
            # Only the driver behind this result's element source can use its element handle.
            with changing_screen(), self.driver.routed_to(getattr(result.strategy.element_source, "driver", None)):
                return act(result.value), None
        except OpticsError as e:
            if e.code in (Code.E0405, Code.E0106):
                raise  # the action ran, or the device is gone: another result cannot do better
            error: Exception = e
        except Exception as e:  # noqa: BLE001 - try the next strategy's result
            error = e
        internal_logger.warning(f"Action '{func_name}' failed with {result.strategy.__class__.__name__}: {error}")
        keyword_outcome.act_failed()
        return None, error

    def _act_until_success(
        self,
        results: Any,
        act: Callable[[Any], Any],
        element: Any,
        func_name: str,
        intent_args: tuple,
        screenshot_np: Any,
        allow_covered: bool = False,
        value: str | None = None,
    ) -> Any:
        """Run ``act`` on each locate result until one succeeds; heal/wrap on failure."""
        last_exception: Optional[Exception] = None
        result_count = 0
        act_ran = False
        locate_error: Optional[OpticsError] = None
        unsupported = True

        # Lazy, so a later strategy locates only after this act fails.
        results_iter = iter(results)
        while True:
            try:
                result = next(results_iter)
            except StopIteration:
                break
            except OpticsError as e:
                # No strategy found it: leave self-heal a chance and keep this error as the cause.
                internal_logger.debug(f"Locate generator raised for '{element}' in '{func_name}': {e}")
                locate_error = e
                break
            result_count += 1
            _save_annotated_for_result(result, screenshot_np, self.capture_output_dir, func_name)
            act_ran = act_ran or not _is_covered(result.value, allow_covered)
            ret, error = self._act_on(result, act, element, func_name, allow_covered)
            if error is not None:
                last_exception = error
                unsupported = unsupported and _unsupported(error)
                continue
            keyword_outcome.acted(result.strategy)
            # Success: record as a breadcrumb for any later AI self-heal (capture-then-return;
            # appending after a bare `return` would be unreachable).
            self._record_successful_step(func_name, element, intent_args, value)
            return ret
        if locate_error is not None and locate_error.code == Code.E0305:
            raise locate_error
        if result_count == 0:
            self._popup_before_self_heal()
            if self._ai_self_heal(element, func_name, intent_args, screenshot_np, value):
                return None
            raise _not_located(element, locate_error)
        heal = partial(self._heal_after_popup_check, act_ran, element, func_name, intent_args, screenshot_np, value)
        return self._after_failed_acts(last_exception, unsupported, element, func_name, heal)

    def _heal_after_popup_check(
        self, act_ran: bool, element: Any, func_name: str, intent_args: tuple, screenshot_np: Any, value: str | None
    ) -> bool:
        seed = screenshot_np
        if self._popup_before_self_heal(retry=not act_ran):
            seed = self._fresh_screenshot()
            if seed is None:
                return False
        return self._ai_self_heal(element, func_name, intent_args, seed, value)

    @staticmethod
    def _after_failed_acts(
        error: Optional[Exception], unsupported: bool, element: Any, func_name: str, heal: Callable[[], bool]
    ) -> None:
        """None when self-heal does the step; else the error that every located result's act ended in."""
        if error is None:
            raise OpticsError(Code.E0801, message=f"{_keyword_name(func_name)} ended with no result and no error for {element_label(element)}")
        if unsupported:
            raise error  # each driver refused the action itself, so no other element or heal can do it
        if heal():
            return None
        raise OpticsError(
            Code.X0201,
            message=f"{element_label(element)} is on the screen, but {_keyword_name(func_name)} failed on it",
            cause=error,
            hint="Make sure that no other element covers it and that it is enabled.",
        )

    def start_popup_run(self) -> None:
        """A served or live request is one run, so its popup limits and events start empty."""
        self._own_popup_run = PopupRun()

    def _popup_run(self) -> PopupRun:
        return test_context.popup_run.get() or self._own_popup_run

    def _popup_io(self) -> PopupIO:
        return PopupIO(
            read_source=self._popup_read_source,
            screen_of=self._popup_screen,
            tap=self._popup_tap,
            tap_at=lambda x, y: self._popup_driver_call("press_coordinates", x, y),
            back=lambda: self._popup_driver_call("go_back"),
            alert=lambda button: self._popup_driver_call("answer_alert", button),
            run_module=self._popup_run_module,
            read_alert=self.driver.read_alert,
            screenshot=self._fresh_screenshot,
            save_image=lambda image, name: utils.save_capture_image(image, name, self.capture_output_dir),
            save_text=lambda text, name: utils.save_capture_text(text, name, self.capture_output_dir),
        )

    def _popup_screen(self, source: Optional[str]) -> PopupScreen:
        """A driver reads its own page source, so the one that gave it parses it."""
        read = getattr(self._popup_source_driver, "popup_screen", None) or self.driver.popup_screen
        return read(source)

    def _popup_read_source(self) -> str:
        page, source = self.strategy_manager.capture_pagesource_from()
        self._popup_source_driver = getattr(source, "driver", None)
        return (page or ("",))[0]

    def _popup_driver_call(self, method: str, *args: Any) -> None:
        """A coordinate comes from the page source of one driver, so only that driver may act on it."""
        with changing_screen(), self.driver.routed_to(self._popup_source_driver):
            getattr(self.driver, method)(*args)

    def _fresh_screenshot(self) -> Any:
        with changing_screen():
            return self._capture_screenshot_safe()

    def _popup_run_module(self, name: str) -> None:
        if self._module_runner is None:
            raise OpticsError(Code.E0601, message=f"Module '{name}' cannot run: these keywords were not built with build_keywords.")
        self._module_runner(name)

    def _popup_tap(self, target: str) -> bool:
        """Tap ``target`` through the locate ladder and the driver. Not through press_element, which would ask the guard again."""
        def act(located: Any) -> None:
            if isinstance(located, tuple):
                self.driver.press_coordinates(*located)
            else:
                self.driver.press_element(located, 1)

        try:
            for result in self.strategy_manager.locate(target):
                if self._act_on(result, act, target, "popup", False)[1] is None:
                    return True
        except OpticsError as e:
            internal_logger.debug(f"Popup target '{target}' not found: {e}")
        return False

    def _popup_before_self_heal(self, retry: bool = True) -> bool:
        """A popup may be why nothing was found: retry the step once a rule has dismissed it, or fail the step here
        rather than let self-heal guess at a screen nobody planned for. With ``retry`` off, because an act ran and
        failed and a retry could repeat it, True says a popup was dismissed."""
        if not self._popup.active:
            return False
        outcome = self._popup.on_failure()
        handled = outcome.verdict is Verdict.HANDLED
        if handled and retry:
            raise OpticsError(Code.E0409)
        self._raise_popup_stop(outcome)
        return handled

    @staticmethod
    def _raise_popup_stop(outcome: Any) -> None:
        if outcome.verdict in (Verdict.STOP, Verdict.UNKNOWN_POPUP):
            raise outcome.error()

    # Click actions
    def press_element(
        self, element: str, repeat: str = "1", offset_x: str = "0", offset_y: str = "0", index: str = "0", aoi_x: str = "0",
        aoi_y: str = "0", aoi_width: str = "100", aoi_height: str = "100", event_name: Optional[str] = None
        ) -> None:
        """
        Press a specified element.

        :param element: The element to be pressed (text, xpath or image).
        :param repeat: Number of times to repeat the press.
        :param offset_x: X offset of the press.
        :param offset_y: Y offset of the press.
        :param index: Index of the element if multiple matches are found.
        :param event_name: The event triggering the press.
        :param aoi_x: X percentage of Area of Interest top-left corner (0-100). Default: 0.
        :param aoi_y: Y percentage of Area of Interest top-left corner (0-100). Default: 0.
        :param aoi_width: Width percentage of Area of Interest (0-100). Default: 100.
        :param aoi_height: Height percentage of Area of Interest (0-100). Default: 100.
        """
        count, dx, dy = _repeat(repeat), _offset(offset_x, "offset_x"), _offset(offset_y, "offset_y")

        def act(located: Any) -> None:
            if isinstance(located, tuple):
                x, y = located
                internal_logger.info(f"Pressing at coordinates ({x + dx}, {y + dy}) with offset ({dx}, {dy})")
                self.driver.press_coordinates(x + dx, y + dy, event_name=event_name)
            else:
                internal_logger.info(f"Pressing element '{element}'")
                self.driver.press_element(located, count, event_name=event_name)

        self._locate_and_act(
            element, "press_element", act, (repeat, offset_x, offset_y),
            index=index, aoi=(aoi_x, aoi_y, aoi_width, aoi_height),
        )

    def press_by_percentage(self, percent_x: str, percent_y: str, repeat: str = "1", event_name: Optional[str] = None) -> None:
        """
        Press an element by percentage coordinates.

        :param percent_x: X percentage of the press (as string, will be converted to float).
        :param percent_y: Y percentage of the press (as string, will be converted to float).
        :param repeat: Number of times to repeat the press.
        :param event_name: The event triggering the press.
        """
        x, y, count = _percent(percent_x, "percent_x"), _percent(percent_y, "percent_y"), _repeat(repeat)
        screenshot_np = self._capture_screenshot_safe()
        self._save_screenshot_if_available(screenshot_np, "press_by_percentage")
        self.driver.press_percentage_coordinates(x, y, count, event_name=event_name)

    def press_by_coordinates(self, coor_x: str, coor_y: str, repeat: str = "1", event_name: Optional[str] = None) -> None:
        """
        Press an element by absolute coordinates.

        :param coor_x: X coordinate of the press.
        :param coor_y: Y coordinate of the press.
        :param repeat: Number of times to repeat the press.
        :param event_name: The event triggering the press.
        """
        x, y = _pixel(coor_x, "coor_x"), _pixel(coor_y, "coor_y")
        screenshot_np = self._capture_screenshot_safe()
        self._save_screenshot_if_available(screenshot_np, "press_by_coordinates")
        internal_logger.info(f'Pressing by coordinates: ({x}, {y})')
        self.driver.press_coordinates(x, y, event_name=event_name)


    def detect_and_press(self, element: str, timeout: str = "30", event_name: Optional[str] = None) -> None:
        """
        Press an element if it appears within ``timeout``; otherwise do nothing.

        When the element never appears the press is skipped and the keyword still succeeds
        (it does not raise), so use it for optional taps such as dismissing a popup that may
        not show. Use ``press_element`` when the target must be present.

        :param element: The element to be detected and pressed (Image template, OCR template, or XPath).
        :param timeout: Seconds to wait for the element to appear.
        :param event_name: The event triggering the press.
        """
        try:
            result = self.verifier.validate_screen(
                element, timeout, rule="any")
        except Exception as e:
            internal_logger.error(f"Error in detect_and_press: {e}")
            result = False
        if result:
            internal_logger.info(f'Element {element} detected. Performing Press ... ')
            self.press_element(element, event_name=event_name)
        else:
            internal_logger.info(f'Element {element} not found. Press is not performed.')

    def press_checkbox(self, element: str, aoi_x: str = "0", aoi_y: str = "0", aoi_width: str = "100",
                       aoi_height: str = "100", event_name: Optional[str] = None, index: str = "0") -> None:
        """
        Press a specified checkbox element.

        .. deprecated:: Deprecated alias of :meth:`press_element` — use ``Press Element`` directly.

        :param element: The checkbox element (Image template, OCR template, or XPath).
        :param aoi_x: X percentage of Area of Interest top-left corner (0-100). Default: 0.
        :param aoi_y: Y percentage of Area of Interest top-left corner (0-100). Default: 0.
        :param aoi_width: Width percentage of Area of Interest (0-100). Default: 100.
        :param aoi_height: Height percentage of Area of Interest (0-100). Default: 100.
        :param event_name: The event triggering the press.
        :param index: Index of the element if multiple matches are found.
        """
        internal_logger.warning("'Press Checkbox' is deprecated; use 'Press Element' instead.")
        self.press_element(element, aoi_x=aoi_x, aoi_y=aoi_y, aoi_width=aoi_width,
                          aoi_height=aoi_height, event_name=event_name, index=index)

    def press_radio_button(self, element: str, aoi_x: str = "0", aoi_y: str = "0", aoi_width: str = "100",
                           aoi_height: str = "100", event_name: Optional[str] = None, index: str = "0") -> None:
        """
        Press a specified radio button.

        .. deprecated:: Deprecated alias of :meth:`press_element` — use ``Press Element`` directly.

        :param element: The radio button element (Image template, OCR template, or XPath).
        :param aoi_x: X percentage of Area of Interest top-left corner (0-100). Default: 0.
        :param aoi_y: Y percentage of Area of Interest top-left corner (0-100). Default: 0.
        :param aoi_width: Width percentage of Area of Interest (0-100). Default: 100.
        :param aoi_height: Height percentage of Area of Interest (0-100). Default: 100.
        :param event_name: The event triggering the press.
        :param index: Index of the element if multiple matches are found.
        """
        internal_logger.warning("'Press Radio Button' is deprecated; use 'Press Element' instead.")
        self.press_element(element, aoi_x=aoi_x, aoi_y=aoi_y, aoi_width=aoi_width,
                          aoi_height=aoi_height, event_name=event_name, index=index)

    def _select_native_option(self, element: str, option: str, event_name: Optional[str]) -> bool:
        """Choose ``option`` in a native list such as an HTML select, whose options are not elements to press."""
        def choose(located: Any) -> bool:
            return not isinstance(located, tuple) and self.driver.select_option(located, option, event_name) is True

        # A probe, not the action: no self-heal, and a failed lookup or selection leaves the dropdown to be opened.
        # Only the first result is asked, since a later strategy is OCR or an image match and gives no element.
        try:
            result = next(iter(self.strategy_manager.locate(element, index=0)), None)
        except OpticsError:
            return False
        return result is not None and self._act_on(result, choose, element, "select_dropdown_option", False)[0] is True

    def select_dropdown_option(self, element: str, option: str, timeout: str = "30",
                                event_name: Optional[str] = None) -> None:
        """
        Open a dropdown and select one of its options, scrolling through the list if needed.

        Opens the dropdown by pressing `element`. If `option` isn't visible right away,
        diffs the interactive elements captured before and after opening to find the
        dropdown's list container, then scrolls within that container (never past the page
        behind it) until `option` appears or the list stops changing. Raises `OpticsError`
        (`E0201``) if `option` is never found within `timeout` seconds.

        Falls back to a single-screen check (no scrolling) when page source, or a list-like
        container, isn't available.

        Assumption: opened dropdown list is opened in such a way that the topmost option is
        visible on the screen

        :param element: The dropdown element (Image template, OCR template, or XPath).
        :param option: The option to select (visible label, OCR/Image template, or XPath).
        :param timeout: Seconds to keep scrolling through the dropdown list before failing.
        :param event_name: The event triggering the selection.
        """
        internal_logger.info(f"Selecting '{option}' from dropdown '{element}'")
        if self._select_native_option(element, option, event_name):
            return
        before = self._safe_get_interactive_elements()
        self.press_element(element, event_name=event_name)

        if self._find_option_element(option):
            # if we find the option without scrolling i.e., its one of the top most options in the dropdown list and
            # can be viewed without scrolling, then just click it and return
            self.press_element(option, event_name=event_name)
            return

        after = self._safe_get_interactive_elements()
        if after is None:
            # page source is unsupported by this setup so we click blindly on the option without any checks
            self.press_element(option, event_name=event_name)
            return

        before_xpaths = {el.get("xpath") for el in (before or []) if isinstance(el, dict)}
        new_elements = [
            el for el in after if isinstance(el, dict) and el.get("xpath") not in before_xpaths
        ]
        container = _find_dropdown_container(new_elements)
        if container is None:
            _raise_option_not_found(element, option, after)

        self._scroll_dropdown_until_found(element, option, container, float(timeout), event_name=event_name)

    def _find_option_element(self, option: str, timeout_str: str = _DROPDOWN_OPTION_CHECK_TIMEOUT) -> bool:
        """
        helper for `select_dropdown_option()`

        Check whether `option` is currently visible on screen
        """
        try:
            return self.verifier.assert_visibility(
                option, timeout_str=timeout_str, rule="any"
            )
        except OpticsError as e:
            if e.code != Code.E0201:
                raise
            return False

    def _safe_get_interactive_elements(self) -> Optional[List[dict]]:
        """
        helper (direct and indirect) for `select_dropdown_option`.

        returns `None` instead of raising when interactive elements aren't available at all,
        so the caller can degrade to a single-screen check instead of crashing.
        """
        try:
            return self.strategy_manager.get_interactive_elements()
        except OpticsError:
            return None

    def _safe_pagesource_hash(self) -> Optional[str]:
        """
        indirect helper for `select_dropdown_option()`

        returns `None` instead of raising when page source isn't available, so the scroll
        loop's "list stopped changing" check can't itself crash `select_dropdown_option`.
        """
        try:
            page_source, _ = self.strategy_manager.capture_pagesource()
        except OpticsError:
            return None
        return utils.compute_hash(page_source) if page_source else None

    def _scroll_dropdown_until_found(
        self, dropdown_element: str, option: str, container: dict,
        timeout: float, event_name: Optional[str],
    ) -> None:
        """
        helper for `select_dropdown_option()`

        Uses `self.driver.swipe(...)` on the already-known container bounds instead of
        `scroll_from_element`: we already have the container, so re-locating it every
        iteration (screenshot + full strategy pipeline) is wasted work and a new failure
        mode (stale xpath). It would also swipe from the container's top edge, not its
        center, risking the gesture landing outside the container.

        Each per-swipe visibility check is clamped to the remaining time budget: left
        unclamped, `_find_option_element`'s own (fixed) polling window could by itself
        push a single iteration well past the caller-specified `timeout`.
        """
        bounds = container["bounds"]
        center_x = (bounds["x1"] + bounds["x2"]) // 2
        center_y = (bounds["y1"] + bounds["y2"]) // 2
        height = max(1, bounds["y2"] - bounds["y1"])
        swipe_length = max(1, int(height * _DROPDOWN_SWIPE_OVERLAP_FACTOR))

        previous_hash = self._safe_pagesource_hash()
        start_time = time.time()
        while time.time() - start_time < timeout:
            self.driver.swipe(center_x, center_y, "up", swipe_length, event_name=event_name)
            time.sleep(1)

            current_hash = self._safe_pagesource_hash()
            remaining = timeout - (time.time() - start_time)
            check_timeout = max(1, min(int(_DROPDOWN_OPTION_CHECK_TIMEOUT), int(remaining)))
            if self._find_option_element(option, timeout_str=str(check_timeout)):
                self.press_element(option, event_name=event_name)
                return
            if previous_hash is not None and current_hash == previous_hash:
                break  # list stopped scrolling; bottom of the list reached
            previous_hash = current_hash

        _raise_option_not_found(dropdown_element, option, self._safe_get_interactive_elements() or [])

    # Swipe and Scroll actions
    def swipe(self, coor_x: str, coor_y: str, direction: str = 'right', swipe_length: str = "50", event_name: Optional[str] = None) -> None:
        """
        Swipe from a point in a specified direction.

        ``direction`` is the way the finger moves: "up" drags bottom to top, which reveals
        content further down. The keyword succeeds whether or not anything moved.

        :param coor_x: X pixel coordinate where the swipe starts.
        :param coor_y: Y pixel coordinate where the swipe starts.
        :param direction: The finger direction (up, down, left, right).
        :param swipe_length: Swipe distance in pixels.
        :param event_name: The event triggering the swipe.
        """
        x, y, length = _pixel(coor_x, "coor_x"), _pixel(coor_y, "coor_y"), _pixel(swipe_length, "swipe_length")
        screenshot_np = self._capture_screenshot_safe()
        self._save_screenshot_if_available(screenshot_np, "swipe")
        internal_logger.info(f'Swiping from ({x}, {y}) to the {direction} with length {length}')
        self.driver.swipe(x, y, direction, length, event_name=event_name)

    def swipe_by_percentage(self, percent_x: str, percent_y: str, direction: str = 'right', swipe_length: str = "50", event_name: Optional[str] = None) -> None:
        """
        Swipe from a screen position, given in percentages, in a specified direction.

        ``direction`` is the way the finger moves: "up" drags bottom to top, which reveals
        content further down. The keyword succeeds whether or not anything moved.

        :param percent_x: Start X as a percentage of screen width (0-100).
        :param percent_y: Start Y as a percentage of screen height (0-100).
        :param direction: The finger direction (up, down, left, right).
        :param swipe_length: Swipe distance as a percentage of screen height (up/down) or width (left/right).
        :param event_name: The event triggering the swipe.
        """
        x, y = _percent(percent_x, "percent_x", int), _percent(percent_y, "percent_y", int)
        length = _percent(swipe_length, "swipe_length", int)
        screenshot_np = self._capture_screenshot_safe()
        self._save_screenshot_if_available(screenshot_np, "swipe_percentage")
        internal_logger.info(f'Swiping from ({x}, {y}) to the {direction} with length {length}')
        self.driver.swipe_percentage(x, y, direction, length, event_name=event_name)

    def swipe_seekbar_to_right_android(self, element: str, event_name: Optional[str] = None) -> None:
        """
        Swipe a seekbar to the right.

        .. deprecated:: Deprecated; prefer :meth:`swipe_from_element` / :meth:`swipe`.

        :param element: The seekbar element (Image template, OCR template, or XPath).
        :param event_name: The event triggering the swipe.
        """
        internal_logger.warning(
            "'Swipe Seekbar To Right Android' is deprecated; use 'Swipe From Element' instead."
        )
        screenshot_np = self._capture_screenshot_safe()
        self._save_screenshot_if_available(screenshot_np, "swipe_seekbar_to_right_android")
        internal_logger.info(f'Swiping seekbar element: {element} to the right')
        self.driver.swipe_element(element, 'right', 50, event_name=event_name)

    def swipe_until_element_appears(self, element: str, direction: str, timeout: str, event_name: Optional[str] = None) -> None:
        """
        Swipe in a specified direction until an element appears.

        :param element: The target element (Image template, OCR template, or XPath).
        :param direction: The swipe direction (up, down, left, right).
        :param timeout: Timeout until element search is performed.
        :param event_name: The event triggering the swipe.
        """
        screenshot_np = self._capture_screenshot_safe()
        self._save_screenshot_if_available(screenshot_np, "swipe_until_element_appears")
        start_time = time.time()
        found = False
        while time.time() - start_time < int(timeout):
            try:
                result = self.verifier.assert_presence(
                    element, timeout_str="3", rule="any")
                if result:
                    found = True
                    break
            except OpticsError as e:
                if e.code != Code.E0201:
                    raise
            self.driver.swipe_percentage(10, 50, direction, 25, event_name=event_name)
            time.sleep(3)
        if not found:
            raise OpticsError(Code.E0201, message=f"{element_label(element)} did not appear after swiping {direction} for {timeout}s.")

    def swipe_from_element(self, element: str, direction: str, swipe_length: str, aoi_x: str = "0", aoi_y: str = "0",
                           aoi_width: str = "100", aoi_height: str = "100", event_name: Optional[str] = None,
                           index: str = "0") -> None:
        """
        Perform a swipe action starting from a specified element.

        :param element: The element to swipe from (Image template, OCR template, or XPath).
        :param direction: The swipe direction (up, down, left, right).
        :param swipe_length: The length of the swipe.
        :param aoi_x: X percentage of Area of Interest top-left corner (0-100). Default: 0.
        :param aoi_y: Y percentage of Area of Interest top-left corner (0-100). Default: 0.
        :param aoi_width: Width percentage of Area of Interest (0-100). Default: 100.
        :param aoi_height: Height percentage of Area of Interest (0-100). Default: 100.
        :param event_name: The event triggering the swipe.
        :param index: Index of the element if multiple matches are found.
        """
        length = _pixel(swipe_length, "swipe_length")

        def act(located: Any) -> None:
            if isinstance(located, tuple):
                x, y = located
                internal_logger.debug(f"Swiping from coordinates ({x}, {y})")
                self.driver.swipe(x, y, direction, length, event_name=event_name)
            else:
                internal_logger.debug(f"Swiping from element '{element}'")
                self.driver.swipe_element(located, direction, length, event_name=event_name)

        self._locate_and_act(
            element, "swipe_from_element", act, (direction, swipe_length),
            index=index, aoi=(aoi_x, aoi_y, aoi_width, aoi_height),
        )

    def scroll(self, direction: str, event_name: Optional[str] = None) -> None:
        """
        Scroll the current view one step in a direction.

        ``direction`` names the way you move through the content: "down" reveals content
        further down. The keyword succeeds whether or not the view actually moved.

        :param direction: up, down, left or right.
        :param event_name: The event triggering the scroll.
        """
        screenshot_np = self._capture_screenshot_safe()
        self._save_screenshot_if_available(screenshot_np, "scroll")
        internal_logger.info(f"Scrolling {direction} with event {event_name}")
        self.driver.scroll(direction, 1000, event_name=event_name)

    def scroll_until_element_appears(self, element: str, direction: str, timeout: str, event_name: Optional[str] = None) -> None:
        """
        Scroll in a specified direction until an element appears.

        :param element: The target element (Image template, OCR template, or XPath).
        :param direction: The scroll direction (up, down, left, right).
        :param timeout: Timeout for the scroll operation.
        :param event_name: The event triggering the scroll.
        """
        screenshot_np = self._capture_screenshot_safe()
        self._save_screenshot_if_available(screenshot_np, "scroll_until_element_appears")
        deadline = time.time() + int(timeout)
        # The screen is checked after every scroll, the last one included.
        while True:
            try:
                if self.verifier.assert_presence(element, timeout_str="3", rule="any"):
                    return
            except OpticsError as e:
                if e.code != Code.E0201:
                    raise
                if isinstance(e, NoLocatorSource):
                    raise
            if time.time() >= deadline:
                raise OpticsError(Code.E0201, message=f"{element_label(element)} did not appear after scrolling {direction} for {timeout}s.")
            self.driver.scroll(direction, 1000, event_name=event_name)
            time.sleep(3)

    def scroll_from_element(self, element: str, direction: str, scroll_length: str, aoi_x: str = "0", aoi_y: str = "0",
                            aoi_width: str = "100", aoi_height: str = "100", event_name: Optional[str] = None,
                            index: str = "0") -> None:
        """
        Perform a scroll action starting from a specified element.

        :param element: The element to scroll from (Image template, OCR template, or XPath).
        :param direction: The scroll direction (up, down, left, right).
        :param scroll_length: The length of the scroll.
        :param aoi_x: X percentage of Area of Interest top-left corner (0-100). Default: 0.
        :param aoi_y: Y percentage of Area of Interest top-left corner (0-100). Default: 0.
        :param aoi_width: Width percentage of Area of Interest (0-100). Default: 100.
        :param aoi_height: Height percentage of Area of Interest (0-100). Default: 100.
        :param event_name: The event triggering the scroll.
        :param index: Index of the element if multiple matches are found.
        """
        length = _pixel(scroll_length, "scroll_length")

        def act(located: Any) -> None:
            if isinstance(located, tuple):
                x, y = located
                internal_logger.debug(f"Swiping from coordinates ({x}, {y})")
                self.driver.swipe(x, y, direction, length, event_name=event_name)
            else:
                internal_logger.debug(f"Swiping from element '{element}'")
                self.driver.swipe_element(located, direction, length, event_name=event_name)

        self._locate_and_act(
            element, "scroll_from_element", act, (direction, scroll_length),
            index=index, aoi=(aoi_x, aoi_y, aoi_width, aoi_height),
        )

    # Text input actions
    def enter_text(self, element: str, text: str, aoi_x: str = "0", aoi_y: str = "0", aoi_width: str = "100",
                   aoi_height: str = "100", event_name: Optional[str] = None, index: str = "0") -> None:
        """
        Enter text into a specified element.

        :param element: The target element (Image template, OCR template, or XPath).
        :param text: The text to be entered.
        :param aoi_x: X percentage of Area of Interest top-left corner (0-100). Default: 0.
        :param aoi_y: Y percentage of Area of Interest top-left corner (0-100). Default: 0.
        :param aoi_width: Width percentage of Area of Interest (0-100). Default: 100.
        :param aoi_height: Height percentage of Area of Interest (0-100). Default: 100.
        :param event_name: The event triggering the input.
        :param index: Index of the element if multiple matches are found.
        """
        register_marked_secret(text)
        typed = utils.parse_special_key(text) or text

        def act(located: Any) -> None:
            if isinstance(located, tuple):
                x, y = located
                internal_logger.debug(f"Entering text at coordinates ({x}, {y})")
                self.driver.press_coordinates(x, y, event_name=event_name)
                self.driver.enter_text(typed, event_name=event_name)
            else:
                internal_logger.debug(f"Entering text into element '{element}'")
                self.driver.enter_text_element(located, typed, event_name=event_name)

        self._locate_and_act(
            element, "enter_text", act,
            index=index, aoi=(aoi_x, aoi_y, aoi_width, aoi_height), value=str(text),
        )

    def enter_text_direct(self, text: str, event_name: Optional[str] = None) -> None:
        """
        Type text into the element that has focus, without waiting for it to accept input.

        To type into a known field, use ``enter_text`` with its locator; on the web it waits until the field accepts input.

        :param text: The text to be entered.
        :param event_name: The event triggering the input.
        """
        register_marked_secret(text)
        self._save_screenshot_if_available(self._capture_screenshot_safe(), "enter_text_keyboard")
        internal_logger.info("Entering text directly")
        self.driver.enter_text(text, event_name=event_name)

    def enter_text_using_keyboard(self, text_input: str, event_name: Optional[str] = None) -> None:
        """
        Enter text or press a special key using the keyboard.

        If the input is a string that includes angle brackets (e.g., '<enter>'),
        the text between the brackets will be interpreted as a special key name and mapped accordingly.

        :param text_input: The text or special key identifier to send.
        :param event_name: Optional event label for logging.
        """
        register_marked_secret(text_input)
        special = utils.parse_special_key(text_input)
        self._save_screenshot_if_available(self._capture_screenshot_safe(), "enter_text_using_keyboard")
        internal_logger.info(f"Pressing {special.value} using keyboard" if special else "Entering text using keyboard")
        self.driver.enter_text_using_keyboard(special or text_input, event_name=event_name)

    def enter_number(self, element: str, number: str, aoi_x: str = "0", aoi_y: str = "0", aoi_width: str = "100",
                     aoi_height: str = "100", event_name: Optional[str] = None, index: str = "0") -> None:
        """
        Enter a specified number into an element.

        :param element: The target element (Image template, OCR template, or XPath).
        :param number: The number to be entered.
        :param aoi_x: X percentage of Area of Interest top-left corner (0-100). Default: 0.
        :param aoi_y: Y percentage of Area of Interest top-left corner (0-100). Default: 0.
        :param aoi_width: Width percentage of Area of Interest (0-100). Default: 100.
        :param aoi_height: Height percentage of Area of Interest (0-100). Default: 100.
        :param event_name: The event triggering the input.
        :param index: Index of the element if multiple matches are found.
        """
        register_marked_secret(number)

        def act(located: Any) -> None:
            if isinstance(located, tuple):
                x, y = located
                internal_logger.debug(f"Entering a number at coordinates ({x}, {y})")
                self.driver.press_coordinates(x, y, event_name=event_name)
                self.driver.enter_text(str(number), event_name=event_name)
            else:
                internal_logger.debug(f"Entering a number into element '{element}'")
                self.driver.enter_text_element(located, str(number), event_name=event_name)

        self._locate_and_act(
            element, "enter_number", act,
            index=index, aoi=(aoi_x, aoi_y, aoi_width, aoi_height), value=str(number),
        )

    def press_keycode(self, keycode: str, event_name: Optional[str] = None) -> None:
        """
        Press a device key by keycode, for system/hardware keys with no on-screen element.

        On Android the keycode is the numeric KeyEvent code (3 = HOME, 4 = BACK, 66 = ENTER,
        187 = RECENTS); TV platform profiles map it to their remote-control key instead.

        :param keycode: The keycode to be pressed.
        :param event_name: The event triggering the press.
        """
        register_marked_secret(keycode)
        self._save_screenshot_if_available(self._capture_screenshot_safe(), "press_keycode")
        internal_logger.info(f"Pressing keycode: {keycode}")
        self.driver.press_keycode(keycode, event_name=event_name)

    def go_back(self, event_name: Optional[str] = None) -> None:
        """Go back one screen: browser history on the web, the back button on a phone."""
        self._save_screenshot_if_available(self._capture_screenshot_safe(), "go_back")
        internal_logger.info(f"Going back one screen with the {type(self.driver).__name__} driver (event: {event_name})")
        self.driver.go_back(event_name=event_name)


    def clear_element_text(self, element: str, aoi_x: str = "0", aoi_y: str = "0", aoi_width: str = "100",
                           aoi_height: str = "100", event_name: Optional[str] = None, index: str = "0") -> None:
        """
        Clear text from a specified element.

        :param element: The target element (Image template, OCR template, or XPath).
        :param aoi_x: X percentage of Area of Interest top-left corner (0-100). Default: 0.
        :param aoi_y: Y percentage of Area of Interest top-left corner (0-100). Default: 0.
        :param aoi_width: Width percentage of Area of Interest (0-100). Default: 100.
        :param aoi_height: Height percentage of Area of Interest (0-100). Default: 100.
        :param event_name: The event triggering the action.
        :param index: Index of the element if multiple matches are found.
        """
        def act(located: Any) -> None:
            if isinstance(located, tuple):
                x, y = located
                internal_logger.debug(f"Clearing text at coordinates ({x}, {y})")
                self.driver.press_coordinates(
                    x, y, event_name=event_name)
                self.driver.clear_text(event_name=event_name)
            else:
                internal_logger.debug(f"Clearing text from element '{element}'")
                self.driver.clear_text_element(located, event_name=event_name)

        self._locate_and_act(
            element, "clear_element_text", act,
            index=index, aoi=(aoi_x, aoi_y, aoi_width, aoi_height),
        )

    def get_text(self, element: str, index: str = "0", aoi_x: str = "0", aoi_y: str = "0",
                 aoi_width: str = "100", aoi_height: str = "100") -> Optional[str]:
        """
        Get the text from a specified element.

        :param element: The target element (XPath, text, or a CSS/DOM XPath locator in a web page).
        :param index: Index of the element if multiple matches are found.
        :param aoi_x: X percentage of Area of Interest top-left corner (0-100). Default: 0.
        :param aoi_y: Y percentage of Area of Interest top-left corner (0-100). Default: 0.
        :param aoi_width: Width percentage of Area of Interest (0-100). Default: 100.
        :param aoi_height: Height percentage of Area of Interest (0-100). Default: 100.
        :return: The text from the element or None for an OCR or image match.
        """
        def act(located: Any) -> Optional[str]:
            if located is None:
                internal_logger.error('get_text: located is None, element could not be found.')
                return None
            if isinstance(located, tuple):
                text = getattr(located, "text", None)
                if text is None:
                    internal_logger.error('Get Text is not supported for coordinate-based (vision) results.')
                return text
            return self.driver.get_text_element(located)

        return self._locate_and_act(
            element, "get_text", act,
            index=index, aoi=(aoi_x, aoi_y, aoi_width, aoi_height), allow_covered=True,
        )

    def sleep(self, duration: str) -> None:
        """
        Sleep for a specified duration.

        :param duration: The duration of the sleep in seconds.
        """
        time.sleep(int(duration))

    def _parse_script_and_args(self, script_or_json: str) -> tuple[str, list]:
        """
        Parse script and args from JSON string or return as-is.

        :param script_or_json: The JavaScript code/script command, or a JSON string.
        :return: Tuple of (script, args)
        """
        script = script_or_json
        args = []

        script_stripped = script_or_json.strip()
        if not script_stripped.startswith('{'):
            return script, args

        try:
            parsed = json.loads(script_or_json)
            if not isinstance(parsed, dict):
                return script, args

            script = parsed.get("script", script_or_json)
            if "args" not in parsed:
                return script, args

            args_value = parsed["args"]
            if isinstance(args_value, list) and len(args_value) == 1 and isinstance(args_value[0], dict):
                args = [args_value[0]]
            elif isinstance(args_value, dict):
                args = [args_value]
            else:
                args = [args_value] if not isinstance(args_value, list) else args_value

            internal_logger.debug(f'Parsed JSON: script="{script}", args={args}')
        except json.JSONDecodeError as e:
            internal_logger.debug(f'Not valid JSON, using as script directly: {e}')

        return script, args

    def execute_script(self, script_or_json: str, event_name: Optional[str] = None) -> Any:
        """
        Execute JavaScript/script in the current context.

        :param script_or_json: The JavaScript code/script command, or a JSON string containing
                               {"script": "...", "args": {...}} or {"script": "..."}.
                               Examples:
                               - "mobile:pressKey" (plain script)
                               - '{"script": "mobile:pressKey", "args": {"keycode": 3}}' (JSON with args)
                               - '{"script": "mobile:clear"}' (JSON without args)
        :param event_name: The event triggering the script execution, if any.
        :return: The result of the script execution.
        :rtype: Any
        """
        self._save_screenshot_if_available(self._capture_screenshot_safe(), "execute_script")

        script, args = self._parse_script_and_args(script_or_json)

        internal_logger.info(f'Executing script: {script[:100]}...')  # Log first 100 chars
        if args:
            result = self.driver.execute_script(script, *args, event_name=event_name)
        else:
            result = self.driver.execute_script(script, event_name=event_name)
        internal_logger.debug(f'Script execution result: {result}')
        return result
