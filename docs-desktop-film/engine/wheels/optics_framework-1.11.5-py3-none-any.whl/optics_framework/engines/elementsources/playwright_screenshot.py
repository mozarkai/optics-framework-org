from typing import Optional, Any, List

from playwright.sync_api import Page
from optics_framework.common.elementsource_interface import EncodedScreenshotSource
from optics_framework.common.logging_config import internal_logger


class PlaywrightScreenshot(EncodedScreenshotSource):
    """
    Capture screenshots using Playwright.
    """

    REQUIRED_DRIVER_TYPE = "playwright"

    page: Optional[Page]

    def __init__(self, driver: Optional[Any] = None):
        self.driver = driver
        self.page = None

    def _require_page(self):
        if self.driver is None or not hasattr(self.driver, "page"):
            raise RuntimeError(
                "Playwright driver is not initialized for PlaywrightScreenshot"
            )
        self.page = self.driver.page
        return self.page

    # --------------------------------------------------
    # Screenshot
    # --------------------------------------------------

    def capture_screenshot_bytes(self) -> bytes:
        """
        Return the viewport as native PNG bytes.

        ``page.screenshot()`` already returns encoded PNG, so this is the cheapest
        path of all backends — no base64 decode and no OpenCV decode/encode at all.
        It is taken at CSS scale: ``mouse.click`` takes CSS pixels, so a screenshot in
        device pixels would put every OCR or image hit at DPR times its true position
        on a browser whose device pixel ratio is above 1.
        """
        page = self._require_page()
        try:
            internal_logger.debug("Capturing Playwright screenshot")
            return self.driver.run(page.screenshot(full_page=False, scale="css"))
        except Exception as e:
            internal_logger.warning(
                "Error capturing Playwright screenshot bytes: %s", e, exc_info=True
            )
            raise RuntimeError(f"Error capturing Playwright screenshot bytes: {e}") from e

    # --------------------------------------------------
    # Unsupported operations
    # --------------------------------------------------

    def get_interactive_elements(self, filter_config: Optional[List[str]] = None):
        """
        Not supported (use PlaywrightPageSource for getting interactive elements).

        Args:
            filter_config: Optional list of filter types (not used for this implementation).
        """
        internal_logger.exception(
            "PlaywrightScreenshot does not support getting interactive elements."
        )
        raise NotImplementedError(
            "PlaywrightScreenshot does not support getting interactive elements."
        )

    def assert_elements(self, elements, timeout=30, rule="any") -> None:
        internal_logger.exception(
            "PlaywrightScreenshot does not support asserting elements."
        )
        raise NotImplementedError(
            "PlaywrightScreenshot does not support asserting elements."
        )

    def locate(self, element, index=None) -> tuple:
        internal_logger.exception(
            "PlaywrightScreenshot does not support locating elements."
        )
        raise NotImplementedError(
            "PlaywrightScreenshot does not support locating elements."
        )

    def locate_using_index(self):
        internal_logger.exception(
            "PlaywrightScreenshot does not support locating elements using index."
        )
        raise NotImplementedError(
            "PlaywrightScreenshot does not support locating elements using index."
        )
