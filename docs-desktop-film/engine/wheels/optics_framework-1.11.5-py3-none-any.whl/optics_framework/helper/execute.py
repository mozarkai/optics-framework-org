import inspect
import os
import shutil
import signal
import threading
import socket
import subprocess  # nosec B404
import sys
import asyncio
from typing import Optional, Tuple, List, Dict, Set, Any, NoReturn
from urllib.parse import urlparse
import yaml
from pydantic import BaseModel, field_validator
from pathlib import Path
from optics_framework.api import ActionKeyword, AppManagement, Verifier
from optics_framework.common.config_handler import Config, DependencyConfig, load_project_yaml, resolve_config_file
from optics_framework.common.logging_config import console_logs_to_stderr, internal_logger, initialize_handlers
from optics_framework.common.runner.data_reader import (
    CSVDataReader,
    YAMLDataReader,
    is_elements_header,
    merge_dicts,
    read_popup_rules,
)
from optics_framework.common.session_manager import SessionManager
from optics_framework.common.error import OpticsError, Code
from optics_framework.common.Junit_eventhandler import get_junit_handler_registry, run_plan
from optics_framework.common.execution import ExecutionEngine, ExecutionParams
from optics_framework.common.runner.event_stream import OutputMode, output_mode_for, prints_lines
from optics_framework.common.models import (
    CaseKind,
    TestCaseNode,
    ModuleNode,
    KeywordNode,
    ElementData,
    ApiData,
    TestSuite,
    ModuleData,
    TemplateData,
    ErrorDefinitions,
    PopupRule,
    merge_popup_rules,
)
from optics_framework.helper.abort import abort_with_panel
from optics_framework.helper.case_selection import select_test_cases


def _reader_accepts_module_names(reader) -> bool:
    try:
        parameters = inspect.signature(reader.read_modules).parameters
    except (TypeError, ValueError):
        return False
    return "module_names" in parameters


def _read_module_names(reader, file_path) -> Set[str]:
    read_names = getattr(reader, "read_module_names", None)
    if read_names is not None:
        return read_names(file_path)
    if _reader_accepts_module_names(reader):
        return set(reader.read_modules(file_path, None))
    return set(reader.read_modules(file_path))


def load_modules(module_files: List[str]) -> ModuleData:
    """Every module the files define; a later file's module of the same name wins."""
    readers: Dict[bool, Any] = {True: CSVDataReader(), False: YAMLDataReader()}
    modules_data = ModuleData()
    # Every module name first, across every file: a YAML step referencing a module is told
    # from a keyword call by name, and the module it names may be defined in another file.
    module_names: Set[str] = set()
    for file_path in module_files:
        module_names |= _read_module_names(readers[file_path.endswith(".csv")], file_path)
    for file_path in module_files:
        reader = readers[file_path.endswith(".csv")]
        modules = (
            reader.read_modules(file_path, module_names)
            if _reader_accepts_module_names(reader)
            else reader.read_modules(file_path)
        )
        for name, definition in modules.items():
            if modules_data.get_module_definition(name):
                internal_logger.warning(f"Duplicate modules key '{name}' found. Overwriting.")
            modules_data.add_module_definition(name, definition)
    return modules_data


def discover_templates(project_path: str) -> TemplateData:
    """
    Discover all image templates in the project directory.

    :param project_path: The path to the project directory.
    :type project_path: str

    :return: TemplateData containing image name to path mappings.
    :rtype: TemplateData
    """
    template_data = TemplateData()
    project_dir = Path(project_path)

    # Common image extensions
    image_extensions = {'.png', '.jpg', '.jpeg', '.bmp', '.tiff', '.tif'}

    # Recursively find all image files
    for image_file in project_dir.rglob('*'):
        if image_file.is_file() and image_file.suffix.lower() in image_extensions:
            template_data.add_template(image_file.name, str(image_file))
    return template_data


def find_files(folder_path: str) -> tuple[list[Any], list[Any], list[Any], list[Any], list[Any], Config | None]:
    """
    Recursively search for CSV and YAML files under `folder_path` and categorize them by content.

    Returns lists of discovered test case, module, element, api and error_definitions files
    and an optional Config object (if a suitable YAML config is found).
    """
    file_collections = _initialize_file_collections()
    config_obj: Config | None = None

    # Walk the directory tree so files in subfolders are discovered
    for root, _dirs, files in os.walk(folder_path):
        for fname in files:
            file_path = os.path.join(root, fname)
            lname = fname.lower()

            # Only consider common file extensions
            if lname.endswith((".yml", ".yaml")):
                config_obj = _process_yaml_file(file_path, file_collections, config_obj, folder_path)
            elif lname.endswith(".csv"):
                _process_csv_file(file_path, file_collections)

    return (
        file_collections["test_case"],
        file_collections["module"],
        file_collections["element"],
        file_collections["api"],
        file_collections["error_definitions"],
        config_obj,
    )


POPUP_RULES_FILE = "popup_rules.json"


def find_popup_rules(folder_path: str) -> list[str]:
    """Paths of the ``popup_rules.json`` files under ``folder_path`` (by name: JSON has no header to sniff), sorted."""
    return sorted(
        os.path.join(root, POPUP_RULES_FILE)
        for root, _dirs, files in os.walk(folder_path)
        if POPUP_RULES_FILE in files
    )


def merge_project_popup_rules(rules: List[PopupRule], folder_path: str) -> List[PopupRule]:
    """``rules`` with every ``popup_rules.json`` in the project merged over them by rule name, as each entry point reads them."""
    for path in find_popup_rules(folder_path):
        rules = merge_popup_rules(rules, read_popup_rules(path))
    return rules


def _initialize_file_collections():
    """Initialize collections for different file types."""
    return {
        'test_case': [],
        'module': [],
        'element': [],
        'api': [],
        'error_definitions': [],
    }


def _process_yaml_file(
    file_path: str, file_collections: dict, current_config: Config | None, folder_path: str
) -> Config | None:
    """Process a YAML file for config detection and content categorization."""
    config_obj = _try_load_config_from_yaml(file_path, current_config, folder_path)
    _categorize_file_by_content(file_path, file_collections)
    return config_obj


def _try_load_config_from_yaml(file_path: str, current_config: Config | None, folder_path: str) -> Config | None:
    """Attempt to load configuration from YAML file."""
    try:
        yaml_data = load_project_yaml(file_path) or {}

        if _is_config_file(yaml_data):
            yaml_data = resolve_config_file(yaml_data, folder_path)
            return Config(**yaml_data)

        return current_config
    except OpticsError as e:
        abort_with_panel([e.message, "", f"Fix it in {file_path}, then re-run."], e.code.value)
    except Exception as e:
        internal_logger.error(f"Failed to load config from {file_path}: {e}")
        return current_config


def _is_config_file(yaml_data: dict) -> bool:
    """Check if YAML data represents a configuration file."""
    return (isinstance(yaml_data, dict) and
            "driver_sources" in yaml_data and
            ("element_sources" in yaml_data or "elements_sources" in yaml_data))


def _process_csv_file(file_path: str, file_collections: dict):
    """Process a CSV file and categorize by content."""
    try:
        _categorize_file_by_content(file_path, file_collections)
    except OpticsError as e:
        abort_with_panel([e.message, "", f"Fix it in {file_path}, then re-run."], e.code.value)


def _categorize_file_by_content(file_path: str, file_collections: dict):
    """Categorize a file based on its content type."""
    content_type = identify_file_content(file_path)

    if "test_cases" in content_type:
        file_collections['test_case'].append(file_path)
    if "modules" in content_type:
        file_collections['module'].append(file_path)
    if "elements" in content_type:
        file_collections['element'].append(file_path)
    if "api" in content_type:
        file_collections['api'].append(file_path)
    if "error_definitions" in content_type:
        file_collections['error_definitions'].append(file_path)


def _identify_csv_content(headers: Optional[Set[str]]) -> Set[str]:
    """
    Identify content types based on CSV headers.

    :param headers: Set of CSV header names.
    :return: Set of content types ('test_cases', 'modules', 'elements').
    """
    content_types = set()
    if headers:
        if {"test_case", "test_step"}.issubset(headers):
            content_types.add("test_cases")
        if {"module_name", "module_step"}.issubset(headers):
            content_types.add("modules")
        if is_elements_header(headers):
            content_types.add("elements")
        elif _misnamed_elements_header(headers):
            raise OpticsError(Code.E0503, message=(
                "The elements file has Element_Name but no Element_ID column, so no element has a locator. "
                "Use the header Element_Name,Element_ID; more locators go in Element_ID_2, Element_ID_3, ..."))
        if {"error_code", "match_string"}.issubset(headers):
            content_types.add("error_definitions")
    return content_types


def _misnamed_elements_header(headers: Set[str]) -> bool:
    """Element_Name with another element_* column, such as Element_Locator: an elements file without Element_ID."""
    return "element_name" in headers and any(h != "element_name" and h.startswith("element_") for h in headers)


def _identify_yaml_content(data: Dict) -> Set[str]:
    """
    Identify content types based on YAML keys.

    :param data: Dictionary loaded from YAML file.
    :return: Set of content types ('test_cases', 'modules', 'elements', 'api').
    """
    content_types = set()
    keys = _normalize_yaml_keys(data)

    if any(k in keys for k in ("test cases", "test_cases", "test-cases", "testcases")):
        content_types.add("test_cases")
    if "modules" in keys:
        content_types.add("modules")
    if "elements" in keys:
        content_types.add("elements")
    if any(k in keys for k in ("api", "apis")):
        content_types.add("api")

    return content_types


def _normalize_yaml_keys(data: Dict) -> Set[str]:
    """
    Return a set of normalized (lowercased and stripped) keys from a YAML mapping.

    This centralizes the normalization logic so other functions can reuse it and
    improves readability.
    """
    if not isinstance(data, dict):
        return set()
    return {str(k).strip().lower() for k in data.keys()}


def identify_file_content(file_path: str) -> Set[str]:
    """
    Identify the content type of a file based on its headers (CSV) or keys (YAML).

    :param file_path: Path to the file.
    :return: Set of content types ('test_cases', 'modules', 'elements').
    """
    if file_path.endswith(".csv"):
        return _identify_csv_content(read_csv_headers(file_path))
    try:
        return _identify_yaml_content(load_project_yaml(file_path) or {})
    except Exception as e:
        internal_logger.exception(f"Error reading {file_path}: {e}")
        return set()


def read_csv_headers(file_path: str) -> Optional[Set[str]]:
    """
    Read and return the headers of a CSV file as a set.

    :param file_path: Path to the CSV file.
    :return: Set of header names or None if reading fails.
    """
    try:
        with open(file_path, "r", encoding="utf-8-sig") as f:
            header = f.readline().strip().split(",")
            return {h.strip().lower() for h in header}
    except (OSError, UnicodeDecodeError) as e:
        internal_logger.exception(f"Error reading {file_path}: {e}")
        return None


def validate_required_files(
    test_case_files: List[str], module_files: List[str], folder_path: str
) -> None:
    """
    Validate that required files (test cases and modules) are present; exit if missing.

    :param test_case_files: List of test case file paths.
    :param module_files: List of module file paths.
    :param folder_path: Path to the project folder.
    """
    if not test_case_files or not module_files:
        missing = [
            f
            for f, p in [("test_cases", test_case_files), ("modules", module_files)]
            if not p
        ]
        error_msg = (
            f"Missing required files in {folder_path}: {', '.join(missing)}. "
            "Run `optics init <name>` to scaffold a complete project."
        )
        internal_logger.error(error_msg)
        abort_with_panel([error_msg], Code.E0501.value)


def filter_test_cases(
    test_cases_dict: Dict[str, Any],
    include: list[str] | None = None,
    exclude: list[str] | None = None,
) -> Dict[str, Any]:
    """Narrow test cases to the include/exclude selection (see ``case_selection``).

    Setup/teardown cases are the ones ``categorize_test_cases`` wires around
    every test, so they always run; a name that merely contains "setup" but
    runs as a regular test is filtered like any other.
    """
    *_, regular_test_cases = categorize_test_cases(test_cases_dict)
    return select_test_cases(
        test_cases_dict, include, exclude, selectable=regular_test_cases.keys()
    )


_WRAPPER_NAMES = (
    (CaseKind.SUITE_SETUP, ("suite", "setup"), "suite setup"),
    (CaseKind.SUITE_TEARDOWN, ("suite", "teardown"), "suite teardown"),
    (CaseKind.SETUP, ("setup",), "test setup"),
    (CaseKind.TEARDOWN, ("teardown",), "test teardown"),
)


def case_kind(name: str) -> CaseKind:
    """A test case wraps the others only when its name ends with "Suite Setup", "Setup" and so on, in any case."""
    words = tuple(name.casefold().split())
    for kind, suffix, _ in _WRAPPER_NAMES:
        if words[-len(suffix):] == suffix:
            return kind
    return CaseKind.TEST


def categorize_test_cases(
    test_cases_data: Dict[str, Any],
) -> Tuple[
    Optional[Tuple[str, Any]],
    Optional[Tuple[str, Any]],
    Optional[Tuple[str, Any]],
    Optional[Tuple[str, Any]],
    Dict[str, Any],
]:
    """Split test cases into suite setup, suite teardown, test setup, test teardown and regular test cases.

    :raises OpticsError: E0503 when two test cases are the same kind of setup or teardown.
    """
    wrappers: Dict[CaseKind, Tuple[str, Any]] = {}
    regular_test_cases = {}
    for name, steps in test_cases_data.items():
        kind = case_kind(name)
        if kind is CaseKind.TEST:
            regular_test_cases[name] = steps
        elif kind in wrappers:
            raise _second_wrapper(kind, wrappers[kind][0], name)
        else:
            wrappers[kind] = (name, steps)
    return (
        wrappers.get(CaseKind.SUITE_SETUP),
        wrappers.get(CaseKind.SUITE_TEARDOWN),
        wrappers.get(CaseKind.SETUP),
        wrappers.get(CaseKind.TEARDOWN),
        regular_test_cases,
    )


def _second_wrapper(kind: CaseKind, first: str, second: str) -> OpticsError:
    suffix, label = next((" ".join(words).title(), label) for k, words, label in _WRAPPER_NAMES if k is kind)
    return OpticsError(Code.E0503, message=(
        f"The test cases have more than one {label}: '{first}' and '{second}'.\n"
        f"A test case whose name ends with '{suffix}' is the {label}. Rename the others."
    ))


def get_execution_queue(test_cases_data: Dict) -> List[Tuple[str, Any, CaseKind]]:
    """Order the test cases to run: suite setup, each test wrapped in its setup and teardown, suite teardown.

    :return: ``(name, steps, kind)`` triples; a test setup or teardown appears once per test, named after it.
    """
    suite_setup, suite_teardown, setup, teardown, regular_test_cases = (
        categorize_test_cases(test_cases_data)
    )
    queue: List[Tuple[str, Any, CaseKind]] = []
    if suite_setup:
        queue.append((*suite_setup, CaseKind.SUITE_SETUP))
    for name, steps in regular_test_cases.items():
        if setup:
            queue.append((f"{setup[0]} ({name})", setup[1], CaseKind.SETUP))
        queue.append((name, steps, CaseKind.TEST))
        if teardown:
            queue.append((f"{teardown[0]} ({name})", teardown[1], CaseKind.TEARDOWN))
    if suite_teardown:
        queue.append((*suite_teardown, CaseKind.SUITE_TEARDOWN))
    return queue


def create_test_case_nodes(queue: List[Tuple[str, Any, CaseKind]]) -> Optional[TestCaseNode]:
    """
    Create a linked list of TestCaseNode objects from the execution queue.

    :param queue: Ordered ``(name, steps, kind)`` triples.
    :return: Head of the TestCaseNode linked list, or None if empty.
    """
    test_suite = TestSuite()
    for tc_name, _, kind in queue:
        test_suite.add_test_case(TestCaseNode(name=tc_name, kind=kind))
    return test_suite.test_cases_head


def populate_module_nodes(
    tc_node: TestCaseNode, modules: List[Any], modules_data: ModuleData
) -> None:
    """
    Populate a TestCaseNode with its ModuleNodes and their KeywordNodes.

    :param tc_node: TestCaseNode to populate.
    :param modules: List of module names for the test case.
    :param modules_data: ModuleData object containing module definitions.
    """
    for module_name in modules:
        module_node = ModuleNode(name=module_name)
        tc_node.add_module(module_node)

        # Get the module definition (list of keywords) from ModuleData
        module_definition = modules_data.get_module_definition(module_name)

        if module_definition:  # Check if the module definition exists
            # Iterate through the keyword definitions in the list
            for keyword_name, keyword_params in module_definition:
                # Create a new KeywordNode for the current test case's module
                keyword_node = KeywordNode(name=keyword_name, params=keyword_params)
                module_node.add_keyword(keyword_node)


def load_api_data(file_path: str) -> ApiData:
    """Loads API data from a YAML file and validates it."""
    if not os.path.exists(file_path):
        raise OpticsError(Code.E0501, message=f"API specification file not found: {file_path}")
    try:
        return ApiData(**load_project_yaml(file_path))
    except yaml.YAMLError as e:
        raise OpticsError(Code.E0503, message=f"Error parsing YAML file: {e}", details={"exception": str(e)})
    except Exception as e:
        raise OpticsError(Code.E0503, message=f"Invalid API data structure: {e}", details={"exception": str(e)})


def build_linked_list(
    test_cases_data: Dict[str, Any], modules_data: ModuleData
) -> TestCaseNode:
    """
    Build a nested linked list structure representing the test execution flow.

    :param test_cases_data: Dictionary mapping test case names to a list of module names.
    :param modules_data: Dictionary mapping module names to a list of (keyword, params) tuples.
    :return: Head of the linked list of TestCaseNode objects representing the full execution flow.
    """
    try:
        queue = get_execution_queue(test_cases_data)

        # Create TestCaseNode linked list
        head = create_test_case_nodes(queue)
        if head is None:
            raise OpticsError(Code.E0702, message="No test cases found to build execution linked list.")

        current = head
        for _, modules, _ in queue:
            populate_module_nodes(current, modules, modules_data)
            current = current.next
        return head
    except Exception as e:
        internal_logger.error(f"Error building linked list: {e}")
        raise OpticsError(Code.E0701, message=f"Failed to build linked list: {e}", details={"exception": str(e)})

_PREFLIGHT_SKIP_ENV = "OPTICS_SKIP_PREFLIGHT"
_PREFLIGHT_SOCKET_TIMEOUT_S = 2.0
_PREFLIGHT_ADB_TIMEOUT_S = 5.0
_APPIUM_DEFAULT_URL = "http://127.0.0.1:4723"
_SELENIUM_DEFAULT_URL = "http://127.0.0.1:4444/wd/hub"


def _probe_tcp(url: str | None, default_port: int,
               timeout: float = _PREFLIGHT_SOCKET_TIMEOUT_S) -> bool:
    """
    Check whether something is listening at ``url`` with a short TCP probe.

    Deliberately a plain socket attempt (no HTTP round-trip, no retries): it
    only answers "is a server reachable there?" within ``timeout`` seconds.
    Missing or unparseable URLs count as unreachable so callers can report the
    real fix instead of an opaque driver error minutes into the run.

    :param url: Server URL from config.yaml (e.g. ``http://127.0.0.1:4723``).
    :param default_port: Port used when an ``http`` URL carries none; an ``https``
        URL without a port means 443.
    :param timeout: Seconds to wait for the connection.
    :return: True when the TCP connection succeeds.
    """
    if not url or not url.strip():
        return False
    try:
        parsed = urlparse(url)
        host = parsed.hostname
        port = parsed.port or (443 if parsed.scheme == "https" else default_port)
    except ValueError:
        return False
    if not host:
        return False
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def _adb_device_count() -> int | None:
    """
    Count attached Android devices/emulators via ``adb devices``.

    Counts only entries in the ``device`` state (offline/unauthorized entries
    cannot be driven) and only after the "List of devices attached" header, so
    daemon banners or error text are never mistaken for devices.

    :return: Device count, or None when adb is missing or cannot be executed —
             letting callers tell "no tooling installed" apart from "no device".
    """
    adb = shutil.which("adb")
    if adb is None:
        return None
    try:
        result = subprocess.run(  # nosec B603
            [adb, "devices"], capture_output=True, text=True,
            timeout=_PREFLIGHT_ADB_TIMEOUT_S, check=False, shell=False)
    except (OSError, subprocess.SubprocessError):
        return None
    in_list = False
    count = 0
    for line in result.stdout.splitlines():
        stripped = line.strip()
        if stripped.startswith("List of devices attached"):
            in_list = True
            continue
        parts = stripped.split() if in_list and stripped else []
        if len(parts) >= 2 and parts[1] == "device":
            count += 1
    return count if in_list else 0


class StartProblem(BaseModel):
    """Why a run cannot start: the panel lines, the first of which names the problem, and the error code."""

    lines: list[str]
    code: str

    @property
    def reason(self) -> str:
        return f"{self.code}: {self.lines[0]}"


def _preflight(config: Config | None, folder_path: str = "<folder>") -> StartProblem | None:
    """
    Beginner-facing environment gate for ``optics execute``, run before any
    test executes so failures surface as guidance instead of a fake
    "Launch App | PASS".

    Checks the first enabled driver from the project's config:

    - playwright: self-contained, skipped silently.
    - selenium: probes the configured WebDriver URL (~2s).
    - appium: probes the configured Appium server URL (~2s); when capabilities
      say Android, additionally requires adb on PATH and one attached device.
      iOS projects get the server probe only.

    On failure returns what is wrong and how to fix it, so the caller can
    report it before it stops the run (dry_run never invokes this gate). Callers pass
    ``None`` when no Config is available (e.g. test doubles) and the gate
    quietly steps aside; a no-driver-enabled config is likewise left to the
    existing gate in ``BaseRunner._setup_session``.

    Set the environment variable ``OPTICS_SKIP_PREFLIGHT`` to ``1`` or
    ``true`` to skip the entire preflight (e.g. for CI images where servers
    are known-good or intentionally absent).

    :param config: The project's resolved configuration.
    :param folder_path: Project folder, used in the re-run hint.
    """
    if os.environ.get(_PREFLIGHT_SKIP_ENV, "").strip().lower() in {"1", "true"}:
        return None
    enabled = next(
        ((name, details)
         for source in (config.driver_sources if config else [])
         for name, details in source.items()
         if details.enabled),
        None,
    )
    if enabled is None:
        return None
    name, details = enabled
    if name == "appium":
        return _preflight_appium(details, folder_path)
    if name == "selenium":
        return _preflight_selenium(details, folder_path)
    return None


def _is_local_server(url: str) -> bool:
    """Whether the server runs on this machine, so its devices are the ones adb sees here."""
    return urlparse(url).hostname in {"localhost", "127.0.0.1", "::1", "0.0.0.0"}  # nosec B104 - a host name compared, not bound


def _preflight_appium(details: DependencyConfig, folder_path: str) -> StartProblem | None:
    """Probe the Appium server and, for Android, adb + an attached device."""
    url = details.url or _APPIUM_DEFAULT_URL
    if not _probe_tcp(url, default_port=4723):
        return StartProblem(lines=[
            f"No Appium server reachable at {url}.",
            "",
            "Start one in another terminal:  appium",
            f"Then re-run:  optics execute {folder_path}",
        ], code=Code.E0102.value)
    platform = str(details.capabilities.get("platformName", "")).lower()
    if platform != "android" or not _is_local_server(url):
        return None
    device_count = _adb_device_count()
    if device_count is None:
        return StartProblem(lines=[
            "Android run requested, but the adb tool was not found.",
            "",
            "Install Android platform-tools (any option that puts adb on PATH),",
            "then check:  adb devices",
            f"Then re-run:  optics execute {folder_path}",
        ], code=Code.E0102.value)
    if device_count == 0:
        return StartProblem(lines=[
            "No Android device/emulator attached (adb reports none).",
            "",
            "Connect a device (USB debugging on) or start an emulator,",
            "then check:  adb devices",
            f"Then re-run:  optics execute {folder_path}",
        ], code=Code.E0102.value)
    return None


def _preflight_selenium(details: DependencyConfig, folder_path: str) -> StartProblem | None:
    """Probe the configured Selenium/WebDriver URL."""
    url = details.url or _SELENIUM_DEFAULT_URL
    if not _probe_tcp(url, default_port=4444):
        return StartProblem(lines=[
            f"No Selenium/WebDriver server reachable at {url}.",
            "",
            "Start one, e.g.:  docker run -d -p 4444:4444 selenium/standalone",
            f"Then re-run:  optics execute {folder_path}",
        ], code=Code.E0102.value)
    return None


class RunnerArgs(BaseModel):
    """Arguments for BaseRunner initialization."""

    folder_path: str
    runner: str = "test_runner"
    use_printer: bool = True
    output: OutputMode | None = None
    include: list[str] | None = None
    exclude: list[str] | None = None

    @field_validator("folder_path")
    @classmethod
    def folder_path_must_exist(cls, v: str) -> str:
        """Ensure folder_path is an existing directory."""
        abs_path = os.path.abspath(v)
        if not os.path.isdir(abs_path):
            raise OpticsError(Code.E0501, message=f"Invalid project folder: {abs_path}")
        return abs_path

    @field_validator("runner")
    @classmethod
    def strip_runner(cls, v: str) -> str:
        """Strip whitespace from runner."""
        return v.strip()


class BaseRunner:
    """Base class for running test cases from CSV and YAML files using ExecutionEngine."""

    def __init__(self, args: RunnerArgs):
        self.folder_path = args.folder_path
        self.runner = args.runner
        self.output = output_mode_for(args.output, args.use_printer)
        self.selection_override = args.include is not None or args.exclude is not None
        internal_logger.debug(f"Using runner: {self.runner}")

        (
            test_case_files,
            module_files,
            element_files,
            api_files,
            error_definition_files,
            config_obj,
        ) = find_files(self.folder_path)
        validate_required_files(test_case_files, module_files, self.folder_path)

        self._init_data_readers()
        self._load_test_cases(test_case_files)
        self._load_modules(module_files)
        self._load_elements(element_files)
        self._load_api_data(api_files)
        self._load_error_definitions(error_definition_files)

        if not self.test_cases_data:
            internal_logger.debug(f"No test cases found in {test_case_files}")

        # Set self.config from config.yaml (or default if missing)
        if config_obj is not None:
            self.config = config_obj
            self.config.project_path = self.folder_path
        else:
            self.config = Config()
        if self.selection_override:
            self.config.include = args.include
            self.config.exclude = args.exclude
        self._load_popup_rules()

        # Load templates after config is set
        self._load_templates()

        # Ensure logging is configured before any test execution
        initialize_handlers(self.config)

        self._filter_and_build_execution_queue()
        self._setup_session()

    def _init_data_readers(self):
        self.csv_reader = CSVDataReader()
        self.yaml_reader = YAMLDataReader()

    def _load_test_cases(self, test_case_files):
        self.test_cases_data: Dict[str, Any] = {}
        for file_path in test_case_files:
            reader = self.csv_reader if file_path.endswith(".csv") else self.yaml_reader
            test_cases = reader.read_test_cases(file_path)
            self.test_cases_data = merge_dicts(
                self.test_cases_data, test_cases, "test_cases"
            )

    def _load_modules(self, module_files):
        self.modules_data: ModuleData = load_modules(module_files)

    def _load_elements(self, element_files):
        """
        Load element data from the provided element files (CSV or YAML).

        :param element_files: List of element file paths.
        :type element_files: list
        :return: Populates self.elements_data with Dict[str, List[str]] for fallback support.
        """
        self.elements_data: ElementData = ElementData()
        for file_path in element_files:
            reader = self.csv_reader if file_path.endswith(".csv") else self.yaml_reader
            elements = reader.read_elements(file_path)
            for name, values in elements.items():
                self._add_or_merge_element(name, values)

    def _add_or_merge_element(self, name, values):
        """Helper to add or merge element values into self.elements_data."""
        # values is a list of element IDs (for fallback)
        if not isinstance(values, list):
            values = [values]
        if self.elements_data.get_element(name):
            # Merge lists, avoid duplicates
            existing = self.elements_data.get_element(name) or []
            for v in values:
                if v not in existing:
                    self.elements_data.elements[name].append(v)
        else:
            self.elements_data.elements[name] = list(values)

    def _load_api_data(self, api_files):
        self.api_data: ApiData = ApiData()
        for file_path in api_files:
            reader = self.yaml_reader  # API files are expected to be YAML
            self.api_data = reader.read_api_data(file_path, existing_api_data=self.api_data)

    def _load_error_definitions(self, error_definition_files):
        self.error_definitions_data: ErrorDefinitions = ErrorDefinitions()
        for file_path in error_definition_files:
            raw = self.csv_reader.read_error_definitions(file_path)
            for code, meta in raw.items():
                self.error_definitions_data.add_error(code, **meta)

    def _load_popup_rules(self):
        """Merge each ``popup_rules.json`` in the project into the session config, over any rule of the same name there."""
        try:
            self.config.popup_rules = merge_project_popup_rules(self.config.popup_rules, self.folder_path)
        except OpticsError as e:
            abort_with_panel([e.message, "", "Fix that popup_rules.json, then re-run."], e.code.value)

    def _load_templates(self):
        """Load template data by discovering image files in the project directory."""
        self.templates_data: TemplateData = TemplateData()
        if hasattr(self.config, 'project_path') and self.config.project_path:
            self.templates_data = discover_templates(self.config.project_path)



    def _filter_and_build_execution_queue(self):
        if not self.test_cases_data:
            self._exit_no_test_cases()
        try:
            categorize_test_cases(self.test_cases_data)
        except OpticsError as e:
            internal_logger.error(e.message)
            abort_with_panel(e.message.splitlines(), e.code.value)
        try:
            self.filtered_test_cases: Dict[str, Any] = filter_test_cases(
                self.test_cases_data, self.config.include, self.config.exclude
            )
        except OpticsError as e:
            self._exit_invalid_selection(e)
        self.execution_queue: TestCaseNode = build_linked_list(
            self.filtered_test_cases, self.modules_data
        )

    def _exit_no_test_cases(self) -> None:
        """Exit with actionable guidance when the project has no test cases."""
        message = (
            f"No test cases to run in {self.folder_path}.\n"
            "Your test_cases file has no rows yet — a freshly created project "
            "starts empty.\n"
            "Add a test case (a row in test_cases/test_cases.csv naming a module) "
            "and define that module in modules/modules.csv, or start from a "
            "ready-made example:\n"
            "    optics init <name> --template <sample>   (see `optics init --help`)\n"
            f"Then re-run:  optics dry_run {self.folder_path}"
        )
        internal_logger.error("No test cases found in %s", self.folder_path)
        abort_with_panel(message.splitlines(), Code.E0702.value)

    def _exit_invalid_selection(self, error: OpticsError) -> NoReturn:
        source = (
            "--include/--exclude"
            if self.selection_override
            else "include/exclude in the project's config.yaml"
        )
        internal_logger.debug("Invalid test case selection: %s", error.message)
        abort_with_panel([
            *error.message.splitlines(),
            "",
            f"Fix the names given via {source}; matching ignores case and accepts * and ? wildcards.",
        ], error.code.value, status=3)

    def _setup_session(self):
        if not self._has_enabled_driver() and self._needs_driver():
            config_path = os.path.join(self.folder_path, "config.yaml")
            abort_with_panel([
                f"No driver enabled in {config_path}.",
                f"Run `optics configure {self.folder_path}`, then re-run.",
            ], Code.E0104.value)
        self.manager: SessionManager = SessionManager()
        try:
            self.session_id: str = self.manager.create_session(
                self.config,
                self.execution_queue,
                self.modules_data,
                self.elements_data,
                self.api_data,
                self.templates_data,
                self.error_definitions_data,
            )
        except OpticsError as error:
            abort_with_panel([
                error.summary,
                "",
                f"Check the setup with:  optics doctor {self.folder_path}",
            ], error.code.value)
        self.engine: ExecutionEngine = ExecutionEngine(self.manager)

    def _has_enabled_driver(self) -> bool:
        return any(
            details.enabled
            for source in self.config.driver_sources
            for details in source.values()
        )

    def _needs_driver(self) -> bool:
        device_keywords = {
            name
            for api_class in (ActionKeyword, AppManagement, Verifier)
            for name in dir(api_class)
            if not name.startswith("_")
        }
        modules = self.modules_data.modules
        pending = [name for steps in self.filtered_test_cases.values() for name in steps]
        seen: set[str] = set()
        while pending:
            name = pending.pop().removeprefix("!").strip()
            if name in seen or name not in modules:
                continue
            seen.add(name)
            for keyword, params in modules[name]:
                if "_".join(keyword.split()).lower() in device_keywords:
                    return True
                pending.extend([keyword, *params])
        return False

    async def run(self, mode: str):
        """Run the specified mode using ExecutionEngine."""
        try:
            params = ExecutionParams(
                session_id=self.session_id,
                mode=mode,
                runner_type=self.runner,
                output=self.output,
            )
            internal_logger.debug(
                f"Executing with runner_type: {self.runner}, output: {self.output.value}"
            )
            return await self.engine.execute(params)
        except Exception as e:
            internal_logger.error(f"{mode.capitalize()} failed: {e}")
            raise
        finally:
            self.cleanup()

    def report_start_failure(self, problem: StartProblem) -> None:
        """Report every queued test case as an error: the run could not start."""
        handler = get_junit_handler_registry().get_handler(self.session_id)
        if handler is not None:
            handler.plan_run(
                self.session_id, run_plan(self.execution_queue), start_error=problem.reason, start_code=problem.code,
            )

    def cleanup(self):
        """Clean up session resources."""
        try:
            self.manager.terminate_session(self.session_id)
        except Exception as e:
            internal_logger.error(f"Failed to terminate session {self.session_id}: {e}")


class ExecuteRunner(BaseRunner):
    async def execute(self):
        """Execute test cases."""
        return await self.run("batch")


class DryRunRunner(BaseRunner):
    async def execute(self):
        """Perform dry run of test cases."""
        return await self.run("dry_run")


def _has_failed_results(results: Any) -> bool:
    return isinstance(results, dict) and any(
        getattr(tc, "status", None) != "PASS" for tc in results.values()
    )


def _output_for_process(output: OutputMode | None, use_printer: bool) -> OutputMode:
    # Only the entry points that own the process move the consoles, so a run_project caller keeps its own.
    mode = output_mode_for(output, use_printer)
    if prints_lines(mode):
        console_logs_to_stderr()
    return mode


def execute_main(
    folder_path: str,
    runner: str = "test_runner",
    use_printer: bool = True,
    include: list[str] | None = None,
    exclude: list[str] | None = None,
    output: OutputMode | None = None,
):
    """Entry point for execute command."""
    output = _output_for_process(output, use_printer)
    if not run_project(folder_path, runner, use_printer, include, exclude, output):
        sys.exit(1)


def run_project(
    folder_path: str,
    runner: str = "test_runner",
    use_printer: bool = True,
    include: list[str] | None = None,
    exclude: list[str] | None = None,
    output: OutputMode | None = None,
) -> bool:
    """Execute a project; True when nothing failed.

    ``include``/``exclude`` replace the selection in config.yaml when either
    is given. ``output`` picks how progress is shown; without it ``use_printer``
    picks ``auto`` or ``none``. Split out of ``execute_main`` so an in-process
    caller can read the outcome instead of catching the ``SystemExit`` the CLI
    reports failure with."""
    args = RunnerArgs(
        folder_path=folder_path, runner=runner, use_printer=use_printer,
        output=output, include=include, exclude=exclude,
    )
    runner_instance = ExecuteRunner(args)
    problem = _preflight(getattr(runner_instance, "config", None), folder_path)
    if problem is not None:
        runner_instance.report_start_failure(problem)
        abort_with_panel(problem.lines, problem.code)
    results = _run_until_stopped(runner_instance.execute())
    return not _has_failed_results(results)


_STOP_SIGNALS = (signal.SIGINT, signal.SIGTERM)


def _run_until_stopped(coroutine):
    """Run ``coroutine``; Ctrl-C and SIGTERM stop it at once, through the session cleanup that writes the JUnit report."""
    if threading.current_thread() is not threading.main_thread():
        return asyncio.run(coroutine)
    previous = {stop: signal.signal(stop, _stop_run) for stop in _STOP_SIGNALS}
    try:
        return asyncio.run(coroutine)
    finally:
        for stop, handler in previous.items():
            signal.signal(stop, handler)


def _stop_run(signum: int, _frame) -> NoReturn:
    # A second stop would cut short the cleanup that writes the report and closes the driver.
    for stop in _STOP_SIGNALS:
        signal.signal(stop, signal.SIG_IGN)
    if signum == signal.SIGINT:
        raise KeyboardInterrupt
    raise SystemExit(128 + signum)


def dryrun_main(
    folder_path: str,
    runner: str = "test_runner",
    use_printer: bool = True,
    include: list[str] | None = None,
    exclude: list[str] | None = None,
    output: OutputMode | None = None,
):
    """Entry point for dry run command."""
    output = _output_for_process(output, use_printer)
    args = RunnerArgs(
        folder_path=folder_path, runner=runner, use_printer=use_printer,
        output=output, include=include, exclude=exclude,
    )
    runner_instance = DryRunRunner(args)
    results = _run_until_stopped(runner_instance.execute())
    note_stream = sys.stderr if prints_lines(output) else sys.stdout
    print("\ndry_run checks the keywords, their params and the names they use. "
          "It does not check locators, the app or the device: optics execute does.", file=note_stream)
    if _has_failed_results(results):
        sys.exit(1)
