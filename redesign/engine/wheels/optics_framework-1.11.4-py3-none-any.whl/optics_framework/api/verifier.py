import time
from typing import Optional, Any, List, Union

from optics_framework.common.error import OpticsError, Code
from optics_framework.common.logging_config import SENSITIVE_PREFIX, internal_logger, mask_secrets
from optics_framework.common import utils
from optics_framework.common.base_factory import InstanceFallback
from optics_framework.common.optics_builder import OpticsBuilder
from optics_framework.common.strategies import StrategyManager
from optics_framework.common.eventSDK import EventSDK
from optics_framework.common.session_liveness import raise_if_session_dead

class Verifier:
    """
    Provides methods to verify elements, screens, and data integrity.
    """

    _ELEMENT_STATES = {
        "enabled": ("enabled", True, "disabled"),
        "disabled": ("enabled", False, "enabled"),
        "checked": ("checked", True, "unchecked"),
        "unchecked": ("checked", False, "checked"),
    }
    _TEXT_POLL_INTERVAL_S = 0.5
    # The assertion loop gives each strategy whole seconds, so a shorter lookup would check nothing.
    _TEXT_MIN_LOOKUP_S = 1.0

    def __init__(self, builder: OpticsBuilder):
        self.driver: InstanceFallback = builder.get_driver()
        self.element_source: InstanceFallback = builder.get_element_source()
        self.image_detection: Optional[InstanceFallback] = builder.get_image_detection()
        self.text_detection: Optional[InstanceFallback] = builder.get_text_detection()
        self.strategy_manager = StrategyManager(
            self.element_source, self.text_detection, self.image_detection,
            annotate_assertions=builder.session_config.save_captures,
        )
        self.event_sdk: EventSDK = builder.event_sdk
        self.capture_output_dir = builder.session_config.capture_dir
        self.session = builder.session

    def validate_element(
        self,
        element: str,
        timeout: str = "10",
        rule: str = "all",
        event_name: Optional[str] = None,
    ) -> None:
        """
        Verifies the specified element.

        :param element: The element to be verified (Image template, OCR template, or XPath).
        :param timeout: The time to wait for verification in seconds.
        :param rule: The rule used for verification ("all" or "any").
        :param event_name: The name of the event associated with the verification, if any.
        """
        internal_logger.debug(f"Validating element: {element}")
        internal_logger.debug(f"Timeout: {timeout} and Rule: {rule}")
        self.assert_presence(element, timeout, rule, event_name=event_name)

    def is_element(
        self,
        element: str,
        element_state: str,
        timeout: int,
        event_name: Optional[str] = None,
    ) -> None:
        """
        Checks if the specified element is in a given state, failing the step if it is not.

        :param element: The element to be checked (Image template, OCR template, or XPath).
        :param element_state: The state to verify (visible, invisible, enabled, disabled, checked, unchecked).
            On the web, an element marked ``aria-disabled="true"`` counts as disabled and
            ``aria-checked`` counts for checked.
        :param timeout: The time to wait for the element in seconds.
        :param event_name: The name of the event associated with the check, if any.
        """
        state = element_state.strip().lower()
        if state in ("visible", "invisible"):
            self._check_visibility(element, state, timeout)
        elif state in self._ELEMENT_STATES:
            self._check_state(element, state)
        else:
            raise OpticsError(
                Code.E0403,
                message=f"Unknown element_state '{element_state}'. "
                        "Expected: visible, invisible, enabled, disabled, checked, unchecked."
            )
        if event_name:
            self.event_sdk.capture_event(event_name)

    def _check_visibility(self, element: str, state: str, timeout: int) -> None:
        try:
            present = self.assert_presence(element, str(timeout), "any", event_name=None, fail=False)
        except OpticsError:
            present = False
        if state == "visible" and not present:
            raise OpticsError(Code.E0401, message=f"Element '{element}' is not visible.")
        if state == "invisible" and present:
            raise OpticsError(Code.E0401, message=f"Element '{element}' is visible but expected invisible.")

    def _check_state(self, element: str, state: str) -> None:
        located = None
        try:
            for result in self.strategy_manager.locate(element):
                located = result.value
                break
        except OpticsError:
            pass
        if located is None:
            raise OpticsError(Code.E0201, message=f"Element '{element}' not found.")
        check, positive, opposite = self._ELEMENT_STATES[state]
        if isinstance(located, tuple):
            actual = getattr(located, check, None)
            if actual is None:
                raise OpticsError(Code.E0401, message=f"Cannot check the {state} state of '{element}': it was found only by OCR or image.")
        elif check == "enabled":
            actual = self.driver.is_element_enabled(located)
        else:
            actual = self.driver.is_element_checked(located)
        if actual != positive:
            raise OpticsError(Code.E0401, message=f"Element '{element}' is {opposite} but expected {state}.")

    def assert_text(self, element: str, expected: str, timeout: str = "10", event_name: Optional[str] = None) -> None:
        """
        Waits until the element's text, or a field's value, equals ``expected``, failing the step if it never does.

        :param element: The element to read (Text, XPath or CSS locator).
        :param expected: The text to expect. Surrounding spaces are ignored on both sides; with an ``@:``
            prefix it is compared without the prefix and both texts are masked in the error.
        :param timeout: The time to wait for the text in seconds.
        :param event_name: The name of the event associated with the check, if any.
        """
        expected = str(expected).strip()
        sensitive = expected.startswith(SENSITIVE_PREFIX)
        want = utils.strip_sensitive_prefix(expected).strip()
        deadline = time.monotonic() + float(timeout)
        while True:
            actual = self._read_text(element, max(deadline - time.monotonic(), self._TEXT_MIN_LOOKUP_S))
            if actual is not None and actual.strip() == want:
                break
            if time.monotonic() >= deadline:
                if actual is None:
                    raise OpticsError(Code.E0201, message=f"Element '{element}' not found.")
                shown = actual.strip()
                if sensitive:
                    shown, want = "****", "****"
                raise OpticsError(Code.E0401, message=mask_secrets(f"Element '{element}' shows '{shown}' but expected '{want}'."))
            time.sleep(self._TEXT_POLL_INTERVAL_S)
        if event_name:
            self.event_sdk.capture_event(event_name)

    def _read_text(self, element: str, timeout: float) -> Optional[str]:
        try:
            # Wait through the assertion loop, which keeps to the timeout; a locate waits as long as the driver does.
            self.strategy_manager.assert_presence([element], utils.determine_element_type(element), timeout=timeout)
            result = next(iter(self.strategy_manager.locate(element)), None)
        except OpticsError as e:
            if not (e.code.value.startswith("E02") or e.code == Code.X0201):
                raise
            return None
        if result is None:
            return None
        if isinstance(result.value, tuple):
            text = getattr(result.value, "text", None)
            if text is None:
                raise OpticsError(Code.E0401, message=f"Cannot read the text of '{element}': it was found only by OCR or image.")
            return text
        try:
            return self.driver.get_text_element(result.value)
        except Exception as e:
            if isinstance(e, OpticsError):
                raise
            raise_if_session_dead(e)
            internal_logger.debug(f"Reading the text of '{element}' failed: {e}")
            return None

    def _resolve_param(self, param: str) -> str:
        """Resolve a `${variable}` reference from session elements, returning its first value."""
        return utils.resolve_scalar_param(self.session, param)

    def assert_equality(self, output: Any, expression: Any, event_name: Optional[str] = None) -> bool:
        """
        Compares two values for equality. Both values are resolved from session
        elements if they are ``${variable}`` references before comparison.

        :param output: The actual value or ``${variable}`` reference.
        :param expression: The expected value or ``${variable}`` reference.
        :param event_name: The name of the event associated with the comparison, if any.
        :return: True when the values are equal; otherwise the step fails.
        """
        actual = self._resolve_param(str(output)).strip()
        expected = self._resolve_param(str(expression)).strip()
        if actual != expected:
            raise OpticsError(Code.E0401, message=mask_secrets(f"Expected '{expected}', got '{actual}'."))
        if event_name:
            self.event_sdk.capture_event(event_name)
        return True

    def assert_presence(self, elements: str, timeout_str: str = "30", rule: str = 'any', event_name: Optional[str] = None, fail: Union[bool, str] = True) -> bool:
        """
        Asserts the presence of elements -- anywhere in the page/DOM, visible or not.

        :param elements: Comma-separated string of elements to check (Image templates, OCR templates, or XPaths).
        :param timeout_str: The time to wait for the elements in seconds.
        :param rule: The rule for verification ("any" or "all").
        :param event_name: The name of the event associated with the assertion, if any.
        :param fail: If True, raise on failure; if False, return False instead. A suite writes
            this as text, and ``False`` is read case-insensitively.
        :return: True if the rule is satisfied, False otherwise.
        """
        return self._assert_common(elements, timeout_str, rule, event_name, fail, method_name="assert_presence")

    def assert_visibility(self, elements: str, timeout_str: str = "30", rule: str = 'any', event_name: Optional[str] = None, fail: Union[bool, str] = True) -> bool:
        """
        Asserts that elements are actually rendered/visible on screen right now -- distinct
        from :meth:`assert_presence`, which reports found even for elements that exist in
        the page/DOM but are off-screen (e.g. not yet scrolled into view).

        :param elements: Comma-separated string of elements to check (Image templates, OCR templates, or XPaths).
        :param timeout_str: The time to wait for the elements to become visible, in seconds.
        :param rule: The rule for verification ("any" or "all").
        :param event_name: The name of the event associated with the assertion, if any.
        :param fail: If True, raise on failure; if False, return False instead. A suite writes
            this as text, and ``False`` is read case-insensitively.
        :return: True if the rule is satisfied, False otherwise.
        """
        return self._assert_common(elements, timeout_str, rule, event_name, fail, method_name="assert_visibility")

    def _assert_common(
        self, elements: str, timeout_str: str, rule: str,
        event_name: Optional[str], fail: Union[bool, str], method_name: str,
    ) -> bool:
        rule = rule.lower()
        timeout = int(timeout_str)
        fail = str(fail).strip().lower() != "false"
        elements_list = elements.split('|')

        grouped_elements = self._group_elements_by_type(elements_list)
        result_parts, timestamps = self._process_element_groups(grouped_elements, timeout, rule, method_name)

        if not result_parts:
            internal_logger.warning("No valid elements provided for assertion.")
            return False

        result = self._evaluate_rule(result_parts, rule)
        self._handle_result(result, timestamps, event_name, fail, rule, method_name)
        return result

    def _group_elements_by_type(self, elements_list: list) -> dict:
        """Group elements by their type (Text, XPath, Image)."""
        types = {el: utils.determine_element_type(el) for el in elements_list}
        return {
            'Text': [el for el in elements_list if types[el] in ('Text', 'CSS')],
            'XPath': [el for el in elements_list if types[el] == 'XPath'],
            'Image': [el for el in elements_list if types[el] == 'Image'],
        }

    def _process_element_groups(self, grouped_elements: dict, timeout: int, rule: str, method_name: str = "assert_presence") -> tuple:
        """Process each group of elements and collect results."""
        result_parts = []
        timestamps = []

        for elem_type, elem_group in grouped_elements.items():
            if elem_group:
                status, timestamp, annotated_frame = getattr(self.strategy_manager, method_name)(elem_group, elem_type, timeout, rule)
                result_parts.append(status)

                if timestamp:
                    timestamps.append(timestamp)

                if annotated_frame is not None:
                    self._save_annotated_screenshot(annotated_frame, timestamp)

        return result_parts, timestamps

    def _save_annotated_screenshot(self, annotated_frame, timestamp):
        """Save annotated screenshot with timestamp."""
        if self.capture_output_dir is None:
            return
        utils.save_screenshot(
            annotated_frame,
            "assert_elements_image_detection_result",
            time_stamp=timestamp,
            output_dir=self.capture_output_dir
        )

    def _evaluate_rule(self, result_parts: list, rule: str) -> bool:
        """Evaluate the rule against the result parts."""
        return any(result_parts) if rule == 'any' else all(result_parts)

    def _handle_result(self, result: bool, timestamps: list, event_name: Optional[str], fail: bool, rule: str, method_name: str):
        """Handle the final result, including event capture and error raising."""
        if result:
            self._capture_success_event(timestamps, event_name=event_name)
        elif fail:
            assertion_label = method_name.replace("assert_", "").capitalize()
            raise AssertionError(f"{assertion_label} assertion failed based on rule: {rule}")

    def _capture_success_event(self, timestamps: list, event_name: Optional[str]):
        """Capture success event with the earliest timestamp."""
        if event_name and timestamps:
            earliest_timestamp = min(timestamps)
            self.event_sdk.capture_event_with_time_input(event_name, earliest_timestamp)


    def validate_screen(self, elements: str, timeout: str = "30", rule: str = 'any', event_name: Optional[str] = None) -> bool:
        """
        Waits for elements and returns whether they appeared, without failing the step.

        Use ``assert_presence`` when a missing element must fail the test.

        :param elements: Comma-separated string of elements to verify (Image templates, OCR templates, or XPaths).
        :param timeout: The time to wait for verification in seconds.
        :param rule: The rule for verification ("any" or "all").
        :param event_name: The name of the event associated with the verification, if any.
        """
        internal_logger.debug(f"Validating screen for elements: {elements}")
        internal_logger.debug(f"Timeout: {timeout} and Rule: {rule}")
        try:
            self.assert_presence(elements, timeout, rule, event_name=event_name, fail=False)
            return True
        except OpticsError as e:
            internal_logger.info(f"Validate Screen: Elements not found. Error: {e}")
            return False
        except Exception as e:
            internal_logger.error(f"Failed to Validate Screen: {e}")
            return False

    def capture_screenshot(self, event_name: Optional[str] = None) -> str:
        """
        Captures a screenshot of the current screen.

        :param event_name: The name of the event associated with the screenshot capture, if any.
        :return: The path to the captured screenshot.
        """
        internal_logger.debug("Capturing screenshot")
        screenshot = self.strategy_manager.capture_screenshot()
        if screenshot is not None:
            internal_logger.debug("Screenshot captured successfully")
            utils.save_screenshot(screenshot, "capture_screenshot", output_dir=self.capture_output_dir)
            screenshot = utils.encode_numpy_to_base64(screenshot)
        else:
            internal_logger.warning("Screenshot capture returned None.")
            screenshot = ""
        if event_name:
            self.event_sdk.capture_event(event_name)
        return screenshot


    def capture_pagesource(self, event_name: Optional[str] = None) -> dict:
        """
        Captures the page source and timestamp of the current screen.

        :param event_name: The name of the event associated with the page source capture, if any.
        :return: Dict with "page_source" and "timestamp" keys.
        """
        internal_logger.debug("Capturing page source")
        result = self.strategy_manager.capture_pagesource()
        if result is not None:
            page_source, timestamp = result
            internal_logger.debug(f"Page source captured at timestamp: {timestamp}")
            utils.save_page_source(page_source, timestamp, self.capture_output_dir)
            if event_name:
                self.event_sdk.capture_event(event_name)
            return {"page_source": page_source, "timestamp": timestamp}
        raise ValueError("Page source capture returned None.")

    def _safe_capture_screenshot_np(self) -> Optional[Any]:
        """Capture a screenshot as a NumPy frame, returning None on failure.

        Bounds scaling and the API image are both derived from this frame; a capture
        failure must degrade to unscaled bounds rather than break element retrieval.
        """
        try:
            return self.strategy_manager.capture_screenshot()
        except Exception as e:
            internal_logger.warning("Failed to capture screenshot for element bounds scaling: %s", e)
            return None

    def _bounds_need_screenshot(self) -> bool:
        """Whether bounds scaling needs a screenshot for the current element source.

        Only Appium sources are rescaled (see ``utils.scale_interactive_element_bounds``),
        so for any other backend we skip the screenshot capture entirely rather than pay
        for a capture whose result would be discarded by a no-op scale.
        """
        source = self.element_source.active_instance
        return utils.is_appium_source(source)

    @staticmethod
    def _to_compact_shape(elements: list) -> list:
        # Project compact dicts to {i, label, cls, bounds:[x1,y1,x2,y2], act, rid?, rid_attr?, loc?, offscreen?}.
        # A payload without an "act" key (a source that does not implement compact)
        # passes through.
        if not elements or not isinstance(elements[0], dict) or "act" not in elements[0]:
            return elements
        return [Verifier._compact_entry(i, el) for i, el in enumerate(elements)]

    @staticmethod
    def _compact_entry(i: int, el: dict) -> dict:
        extra = el.get("extra") or {}
        bounds = el.get("bounds") or {}
        entry = {
            "i": i,
            "label": el.get("text") or "",
            "cls": extra.get("class") or "",
            "bounds": [bounds.get("x1"), bounds.get("y1"), bounds.get("x2"), bounds.get("y2")],
            "act": el.get("act") or [],
            **Verifier._compact_id(extra),
        }
        if el.get("loc"):
            entry["loc"] = el["loc"]
        if el.get("offscreen"):
            entry["offscreen"] = True
        return entry

    @staticmethod
    def _compact_id(extra: dict) -> dict:
        """The element's id as ``rid``; ``rid_attr`` names the attribute when it is not ``resource-id``."""
        if extra.get("resource-id"):
            return {"rid": extra["resource-id"]}
        return {"rid": extra["id"], "rid_attr": "id"} if extra.get("id") else {}

    def _collect_interactive_elements(
        self, filter_config: Optional[List[str]], screenshot_np: Optional[Any], compact: bool = False
    ) -> list:
        """Fetch interactive elements, CSV-escape their text/xpath, and scale their
        bounds into the given screenshot's pixel space.

        Shared by ``get_interactive_elements``, ``get_screen_elements``, and the serve
        workspace stream so all three return consistent, screenshot-aligned bounds from
        a single capture. Does not persist anything — callers decide whether to save.
        """
        elements = self.strategy_manager.get_interactive_elements(filter_config, compact=compact)
        for el in elements:
            if isinstance(el, dict):
                if "xpath" in el and el["xpath"] is not None:
                    el["xpath"] = utils.escape_csv_value(str(el["xpath"]))
                if "text" in el and el["text"] is not None:
                    el["text"] = utils.escape_csv_value(str(el["text"]))
        # Bounds come from the page source in the driver's window coordinate space;
        # scale them to the screenshot's pixel space so consumers can overlay them
        # directly (no-op on Android / non-Appium / when sizes already match).
        utils.scale_interactive_element_bounds(elements, self.element_source, screenshot_np)
        return elements

    def get_interactive_elements(self, filter_config: Optional[List[str]] = None, compact: bool = False) -> list:
        """
        Retrieves a list of interactive elements on the current screen.

        XPath and text fields are converted to one-line, CSV-friendly form (newlines
        as \\n, tabs as \\t, etc.) so output can be pasted into elements.csv or similar.
        On Appium sources, element bounds are returned in the screenshot's pixel space.

        :param filter_config: Optional list of filter types (e.g., ["buttons", "inputs"]).
        :param compact: When True, return only actionable elements (labels folded in,
            with an ``act`` list) plus standalone visible text (``act: []``), as
            ``{i, label, cls, bounds:[x1,y1,x2,y2], act, rid?, rid_attr?, loc?, offscreen?}`` (``loc``: a web
            locator matching only that element; ``offscreen``: in the page but scrolled out of
            view). Implemented by the Appium, Appium web and Playwright page sources; sources
            without it return their full list.
        :return: A list of interactive elements.
        """
        compact = utils.to_bool(compact)
        screenshot_np = self._safe_capture_screenshot_np() if self._bounds_need_screenshot() else None
        elements = self._collect_interactive_elements(filter_config, screenshot_np, compact=compact)
        if compact:
            elements = self._to_compact_shape(elements)
        utils.save_interactable_elements(elements, output_dir=self.capture_output_dir)
        return elements

    def get_screen_elements(self) -> dict:
        """
        Captures a screenshot and retrieves interactive elements for API response.

        Bounds are scaled to the returned screenshot's pixel space using a single
        capture shared between the image and the bounds, so callers can overlay the
        bounds on the screenshot without any scaling of their own.

        :return: Dict with base64-encoded screenshot and list of elements.
        """
        screenshot_np = self._safe_capture_screenshot_np()
        elements = self._collect_interactive_elements(None, screenshot_np)
        utils.save_interactable_elements(elements, output_dir=self.capture_output_dir)
        if screenshot_np is not None and self.capture_output_dir is not None:
            utils.save_screenshot(screenshot_np, "capture_screenshot", output_dir=self.capture_output_dir)
        base64_screenshot = (
            utils.encode_numpy_to_base64(screenshot_np) if screenshot_np is not None else ""
        )
        return {
            "screenshot": base64_screenshot,
            "elements": elements
        }
